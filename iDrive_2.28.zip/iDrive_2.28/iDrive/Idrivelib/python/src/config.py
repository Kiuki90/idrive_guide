import os, subprocess

appname     = 'IDrive'.lower()
version     = '2.27'
releasedate = '05/07/2020'

servicelocationfilename    = ".serviceLocation"
userprofiledirname         = "user_profile"
osuser                     = subprocess.check_output(["whoami"]).strip().decode()
cachedirname               = "cache"
usernamefilename           = "idriveuser.txt"
userinfodirname            = ".userInfo"
idenpwdfilename            = "IDENPWD"
logdirname                 = "LOGS"
backupsetfilename          = "BackupsetFile.txt"
crontabfilename            = (appname + "crontab.json")

userconfigurationfilename = "CONFIGURATION_FILE"

uidprefix = "Linux"
minevsbatchcount = 2
maxevsbatchcount = 4

__userprofilepathschema = os.path.join("__SERVICEPATH__", userprofiledirname, osuser, "__USERNAME__")
schemas = {
	"jobs": {
		"backup"     : {
			"type"   : "backup",
			"path"   : os.path.join(__userprofilepathschema, "Backup", "DefaultBackupSet"),
			"logsdir": os.path.join(__userprofilepathschema, "Backup", "DefaultBackupSet", logdirname),
			"file"   : os.path.join(__userprofilepathschema, "Backup", "DefaultBackupSet", backupsetfilename),
			"runas"  : ["SCHEDULED", "immediate"],
			"croncmd": "%s %s %s", # Script name & username
		},
		"localbackup": {
			"type"   : "backup",
			"path"   : os.path.join(__userprofilepathschema, "Backup", "LocalBackupSet"),
			"logsdir": os.path.join(__userprofilepathschema, "Backup", "LocalBackupSet", logdirname),
			"file"   : os.path.join(__userprofilepathschema, "Backup", "LocalBackupSet", backupsetfilename),
			"runas"  : ["SCHEDULED", "immediate"],
			"croncmd": "%s SCHEDULED %s", # Script name & username
		},
		"restore"    : {
			"type"   : "restore",
			"path"   : os.path.join(__userprofilepathschema, "Backup", "DefaultRestoreSet"),
			"logsdir": os.path.join(__userprofilepathschema, "Backup", "DefaultRestoreSet", logdirname),
			"file"   : os.path.join(__userprofilepathschema, "Backup", "DefaultRestoreSet", backupsetfilename),
			"runas"  : [],
			"croncmd": "",
		},
		"archive"    : {
			"type"   : "archive",
			"path"   : os.path.join(__userprofilepathschema, "Backup", "DefaultBackupSet"),
			"logsdir": os.path.join(__userprofilepathschema, "Backup", "DefaultBackupSet", logdirname),
			"file"   : os.path.join(__userprofilepathschema, "Backup", "DefaultBackupSet", backupsetfilename),
			"runas"  : ["SCHEDULED"],
			"croncmd": "%s %s %s %s %s", # script name, username, percentage, days & timestamp
		}
	}
}
