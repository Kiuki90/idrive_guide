from setuptools import setup
from Cython.Build import cythonize

setup(
    name='idriveutl',
    ext_modules=cythonize("idriveutl.pyx"),
    zip_safe=False,
)
