import os, sys, requests, json, binascii, base64
from Crypto.Cipher import AES
from collections_extended import IndexedDict

class idriveutl:
	def __init__(self, args, helpers):
		self.args = args
		self.helpers = helpers
		self.proxy = {}

	def __getad(self, p):
		acs = base64.b64encode("".join(dir(idriveutl)).encode()).decode()
		a1 = ""
		a2 = ""
		for x in range(1, 5):
			a1 += acs[(x*9): ((x*9)+4)]
			a2 += acs[(x*15): ((x*15)+4)]

		aes = AES.new(a1, AES.MODE_CBC, a2)
		r = aes.decrypt(base64.b64decode(p))
		r = r.replace(chr(1).encode(), b"")
		r = self.helpers.fromjson(r.decode())
		return r

	def __getp(self, a, nf = 0, ur = 0):
		p = self.__getad(a)
		self.helpers.loadservicepath()
		pfn = os.path.join(self.helpers.getservicepath(), (self.args[2] + ".p"))
		if (os.path.isfile(pfn)):
			fh = open(pfn, "r")
			prxy = ""
			for l in fh:
				prxy += binascii.a2b_uu(l.strip()).decode()
			fh.close()
			self.proxy = {
				"http" : prxy,
				"http" : prxy
			}
			os.remove(fn)

		fn = os.path.join(self.helpers.getservicepath(), self.args[2])
		fc = []
		if (nf):
			for c in range(1, len(p)):
				try:
					fh = open((fn + "." + str(c)), "r")
					fc.append(fh.read().strip())
					fh.close()
				except IOError as e:
					fc = []
					print("IOError: getfilecontent", e)
					# TODO: log file read errors

				os.remove((fn + "." + str(c)))
		else:
			try:
				fh = open(fn, "r")
				fc = ""
				for l in fh:
					fc += binascii.a2b_uu(l.strip()).decode()
				fc = self.helpers.fromjson(fc)
				fh.close()
			except IOError as e:
				fc = []
				print("IOError: getfilecontent", e)
				# TODO: log file read errors

			os.remove(fn)

		rd = IndexedDict()
		for c in range(1, len(p)):
			if (ur):
				ur = 0
				p[0] = p[0].replace("__RPL__", fc[(c - 1)])
			else:
				rd[p[c]] = fc[(c - 1)]

		return p[0], rd

	def __request(self, l, d):
		return requests.post(l, data = d, proxies = self.proxy)

	def __request2(self, l, p):
		return requests.get(l, params = p, proxies = self.proxy)

	def d1(self):
		p1, p2 = self.__getp(b"Lc2Hc03nxBpFvozEKHup1QjFpAWo5PZV3dq/Za2fSyVHlevOKZe92Y0bqDuLU1oBJHtv7eD8rJSYa+atTxm16Tnr2xNHpIf5/S4xNSxmBrQ=")
		r = self.__request(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def d2(self):
		p1, p2 = self.__getp(b"Lc2Hc03nxBpFvozEKHup1QjFpAWo5PZV3dq/Za2fSyXKbanZnaEf/PQI8uUriC2Mfg525qM8TXcIEJVOo9TgVQ==")
		r = self.__request(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def d3(self):
		p1, p2 = self.__getp(b"lgFUe4t13RWA+jv593jpqjQ5aiBItMZSYhGgXRJJHIxNwqMwQPML9r4PeXmaX7v14yYKCZA+AgBs/ubgbWvqGbBRPsnCmDNTHL1w43055BoqpTHHCVTFSTg+qbBh1vPW7SDpSSHUyPqf6B0UWTwPFg==", -1)
		r = self.__request(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def d4(self):
		p1, p2 = self.__getp(b"Lc2Hc03nxBpFvozEKHup1QiY6giVUH80r5EJDNemHePjD9nG0+8EPrz+waMm/1TVdfIFEbdieYuSnqKkuDwGgZF5lCSOYNCnbNgZ5x4oqgRjBcNdVA5jl8OxlYIo6G5xoDs5//c3UnCH6XJgLPM+QQ==")
		r = self.__request2(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def d5(self):
		p1, p2 = self.__getp(b"Lc2Hc03nxBpFvozEKHup1QjFpAWo5PZV3dq/Za2fSyU0WKc80cyNqWDQ0flzhTDkXSCzsUzr/SBDLXHWhrLxVtL8RdXITa1rLqZtz/vb7e63ypN3Q0PZDAqADK6/FY7NMI09trgogbP8OHe9wy2myYhCPEXvV+hbbisYexGQq0mLWLynUi9T5cy9mbLVODpyA6qekgEtERLo3UNCc/rFkvdSVYNKZ8PRl3/yjAyZAE6l80oHY5fuFxOMQrZyeHvLZKZtcZ6Jvo3Y374Iylz+AbqJResA4zfsY/u0pjJpiA1YZjOZtoAxP3t1MHjGMCF7ht5svqqTZrvO+qIZI37qFwGiOlEZtiGO3fIoNcEmXd0yUu2ah7b990w5okyD1eF8")
		r = self.__request(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def d6(self):
		p1, p2 = self.__getp(b"lgFUe4t13RWA+jv593jpqjQ5aiBItMZSYhGgXRJJHIx4qHFpdKzSBJEVy0z8ZUDuCl6PShXzBPFM3olL1wki2jAUGLUw6U10WEKkuqffsmW+TaubitCNmikeIEq88UWgapvBOZU0XKjzbwzGwdcu4oKNxPsWq4hjqPiiXo1iP2k=")
		r = self.__request(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def d7(self):
		p1, p2 = self.__getp(b"Lc2Hc03nxBpFvozEKHup1QjFpAWo5PZV3dq/Za2fSyUmR87kfSe5OVJ/iqQ9U1MKpL+BiaIBtIcwjv5Up0i7dK/6TJ051AG7AUEZVXYqRSa6CU6HVjlmWQkHUBuVeFpIa0A8xg3gljjrqL/SOjWTygoELEavYRrkb05pXwnT60nwV7FreCScsP23bGQTmwPx")
		r = self.__request(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def d8(self):
		p1, p2 = self.__getp(b"dIz28iwNWSLt2FabUFLA4lsyki5Un8wnX2nF2lO9nyUahqmYW4jQRMX6PaYqWGPSW4cUsdPCqVNz90oHHBF/bmkKNsTNz0A08Yv8TSoSuVE=", 0, 1)
		r = self.__request(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def d9(self):
		p1, p2 = self.__getp(b"dIz28iwNWSLt2FabUFLA4uWNoWn9MABQ08coMP9ryoPP1e8VBGnjx67JIMlOfZ2W8DSLvmiQHJr3HJpuW/Q8Lg==", 0, 1)
		r = self.__request(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def d10(self):
		p1, p2 = self.__getp(b"/kGltN4a5TPVg6GvtW4qfUyFQ7W42A7D3AZJMTKUFy+5XwRBKLwrCsxmHig171JuQbA8vfyKJ0ZlHZJrtU/cAXc+uZ5uy9LwuY5mNxMLbYM=")
		r = self.__request(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def d11(self):
		p1, p2 = self.__getp(b"7HV4GdDqz/Z5XSfZMWmnmVo62U/rFxZoYf2pwdyozayo2p7JHIbKnwenN9vx/nr3JGrf6mvJito/vB1nFGB5vudjl91BytPYUE1EJA62tJ8tgqUQtkllxqVzJJnNrx2D")
		r = self.__request(p1, p2)
		# TODO: Error handling
		return {
			"STATUS": "SUCCESS",
			"DATA"  : r.content.decode("utf-8")
		}

	def getd(self):
		return getattr(self, ("d" + self.args[1]))()
