import sys
from cx_Freeze import setup, Executable
# import requests

executable = Executable("idrivescripts.py")

# Add certificate to the build
# options = {
#     "build_exe": {
#         # 'include_files' : [(requests.certs.where(), 'cacert.pem')],
#
#     }
# }

build_exe_options = {
	"packages"    : ["idna"],
	"bin_includes": [
		"libssl.so.1.0.0",
		"libcrypto.so.1.0.0",
	]
}

setup(
	name    = "IDrive",
	version = "0.1",
	decription = "IDrive Scripts!",
	options    = {"build_exe": build_exe_options},
	executables = [executable]
)

# setup(
#     version = "0",
#     # requires = ["requests"],
#     options = options,
#     executables = [executable]
# )
