import os, sys, json, requests, queue, binascii
from Crypto.Cipher import AES
from collections_extended import IndexedDict

from helpers import helpers
from idriveutl import idriveutl
import config

class idrivescripts:
	def __init__(self, args):
		self.args    = args
		self.helpers = helpers()

	def run(self):
		if (self.args[1] == "-v"):
			print(config.version)
			sys.exit(0)
		return self.helpers.tojson(idriveutl(self.args, self.helpers).getd())

if __name__ == "__main__":
	print(idrivescripts(sys.argv).run())
