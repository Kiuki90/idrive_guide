import os, sys, pathlib, subprocess, re, json, binascii, base64, stat, socket
import config

class helpers:
	def __init__(self):
		self.__loadapppath();

	def fromjson(self, string, returntype = ""):
		try:
			data =  json.loads(string)
		except ValueError:
			data = returntype

		return data

	def tojson(self, pytype):
		return json.dumps(pytype)

	def getipaddress(self):
		ipaddress = "0.0.0.0"
		if (os.path.isfile('/sbin/ip')):
			ipaddr = subprocess.check_output(["/sbin/ip", "r"]).splitlines()
			for line in ipaddr:
				if (re.search(" src ", line)):
					ipaddress = line.split(" src ")[1].strip()
					break
		return ipaddress

	def gethostname(self):
		return socket.gethostname()

	def __loadapppath(self):
			self.__apppath = str(pathlib.Path(__file__).parent.parent.parent.parent.absolute())

	def getapppath(self):
		return self.__apppath

	def loadservicepath(self):
		if (os.path.isfile(os.path.join(str(self.__apppath), config.servicelocationfilename))):
			self.__servicepath = self.getfilecontent(os.path.join(str(self.__apppath), config.servicelocationfilename))
			return True
		else:
			self.__servicepath = ""
			return False

	def getservicepath(self):
		if (not self.__servicepath):
			self.loadservicepath()

		return self.__servicepath

	def savetofile(self, filename, content):
		status = None
		try:
			f = open(filename, 'w+').write(content)
			status = True
		except IOError as e:
			status = False
			print("IOError: getfilecontent", e)
			# TODO: log file read errors

		return status

	def savetofile2(self, filehandler, content):
		filehandler.write(content)

	def getfilecontent(self, filename):
		try:
			fh = open(filename, 'r')
			fc = fh.read().strip()
			fh.close()
		except IOError as e:
			fc = ''
			print("IOError: getfilecontent", e)
			# TODO: log file read errors

		return fc

	def getfilecontent2(self, filehandler):
		try:
			fc = filehandler.read().strip()
		except IOError:
			fc = ''
			print("IOError: getfilecontent")
			# TODO: log file read errors

		return fc

	def __getusernamefile(self):
		return os.path.join(self.getservicepath(), config.cachedirname, config.usernamefilename)

	def loadusername(self):
		ufile = self.__getusernamefile()
		self.__username = ""
		if (os.path.isfile(ufile)):
			fh = open(ufile, "r")
			username = fh.read().strip()
			fh.close()
			if (username):
				username = self.fromjson(username)
				self.__username = username[config.osuser]["userid"]

	def getusername(self):
		try:
			if (not self.__username):
				self.loadusername()
		except AttributeError:
			self.loadusername()

		return self.__username

	def getuserprofilepath(self):
		return os.path.join(self.getservicepath(), config.userprofiledirname,
							config.osuser, self.getusername())

	def buildpath(self, path):
		path = path.replace("__SERVICEPATH__", self.getservicepath())
		path = path.replace("__USERNAME__", self.getusername())

		return path

	def __getidenpwdfile(self):
		return os.path.join(self.getuserprofilepath(), config.userinfodirname, config.idenpwdfilename)

	def decodepwd(self):
		idenpwdfile = self.__getidenpwdfile()
		idenpwd = ""
		if (os.path.isfile(idenpwdfile)):
			fh = open(idenpwdfile, "r")
			p = fh.read().strip()
			fh.close()
			idenpwdlen = len(p)
			parts = p.split("_", 1)
			p = binascii.a2b_uu(parts[1])
			if (len(self.getusername()) == int(parts[0])):
				idenpwd = p

		return idenpwd

	def encryptstring(self, plainstring):
		if (not plainstring):
			return ""

		plainstring    = base64.b64encode(plainstring)
		plainstringlen = len(plainstring)
		swaplen        = (plainstringlen - (plainstringlen % 4))
		shiftlen       = (swaplen/4)

		swpa = plainstring[0:shiftlen]
		swpb = plainstring[(3 * shiftlen):][:shiftlen]

		encryptedstring = (plainstring[:(3 * shiftlen)] + swpa + plainstring[((3 * shiftlen) + shiftlen):])
		encryptedstring = (swpb + encryptedstring[shiftlen:])

		return encryptedstring

	def decryptstring(self, encryptedstring):
		if (not encryptedstring):
			return ""

		encryptedstringlen = len(encryptedstring)
		swaplen    = (encryptedstringlen - (encryptedstringlen % 4))
		shiftlen   = int(swaplen/4)

		swpa = encryptedstring[0:shiftlen]
		swpb = encryptedstring[(3 * shiftlen):][:shiftlen]

		newstr = (encryptedstring[:(3 * shiftlen)] + swpa + encryptedstring[((3 * shiftlen) + shiftlen):])
		newstr = (swpb + newstr[shiftlen:])

		return base64.b64decode(newstr)

	def __getuserconfigurationfile(self):
		return os.path.join(self.getservicepath(), config.userprofiledirname,
							config.osuser, self.getusername(), config.userconfigurationfilename)

	def loaduserconfigurations(self):
		userconfigfile = self.__getuserconfigurationfile()
		errcode = 1
		if (os.path.isfile(userconfigfile)):
			self.userconfig = self.fromjson(self.decryptstring(self.getfilecontent(userconfigfile)).decode())
		else:
			errcode = 104

		return errcode

	def verifyfilesetcontent(self, files):
		updatedfiles = []
		for file in files:
			file = file.strip()

			if (not file):
				continue

			p = re.compile("[\/]+")
			file = p.sub("/", file)

			if ((file == ".") or (file == "..") or (file == "/")):
				continue

			if (not file.startswith("/")):
				file = ("/" + file)

			updatedfiles.append(file)

		return updatedfiles

	def getfilestat(self, files):
		details = {}
		for file in files:
			if not os.path.exists(file):
				continue
			if (os.path.islink(file) or
				stat.S_ISFIFO(os.stat(file).st_mode) or
				stat.S_ISSOCK(os.stat(file).st_mode) or
				stat.S_ISBLK(os.stat(file).st_mode) or
				stat.S_ISCHR(os.stat(file).st_mode)):
				continue

			if (os.path.isfile(file)):
				details[file] = {"type": "f"}
			elif(os.path.isdir(file)):
				details[file] = {"type": "d"}

		return details
