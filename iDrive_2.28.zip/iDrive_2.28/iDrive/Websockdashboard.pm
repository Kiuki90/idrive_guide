#*****************************************************************************************************
# Dashboard client service script
#
# Created By : Yogesh Kumar @ IDrive Inc
# Reviewed By: Deepak Chaurasia
#
# IMPORTANT  : Please do not run this script manually. Run dashboard using account_setting.pl
#*****************************************************************************************************

package Websockdashboard;
use strict;
use warnings;

$| = 1;

eval {
	require Idrivelib;
	Idrivelib->import();
	1;
} or do {
	$AppConfig::displayHeader = 0;
	Common::retreat('you_cant_run_supporting_script');
	exit 1;
};

use lib map{if(__FILE__ =~ /\//) { substr(__FILE__, 0, rindex(__FILE__, '/'))."/$_";} else { "./$_"; }} qw(Idrivelib/lib);

use Sys::Hostname;
use POSIX ":sys_wait_h";
use IO::Socket::SSL;
use IO::Select;
use Protocol::WebSocket::Client;
use Scalar::Util qw(reftype looks_like_number);
use POSIX;
use POSIX qw< :signal_h >;
use Errno qw( EINTR );
use Fcntl qw(:flock);

use Common qw(retreat getUserConfiguration setUserConfiguration saveUserConfiguration getUsername getParentUsername getServicePath getParentRemoteManageIP getRemoteManageIP getRemoteAccessToken getMachineUser getCatfile getUserProfilePath loadNotifications setNotification saveNotifications loadNS getNS saveNS deleteNS getFileContents);
use AppConfig qw(TRUE FALSE STATUS SUCCESS FAILURE);

use JSON qw(from_json to_json);
use DashboardUtility;
use PropSchema;
use IO::Zlib;
use MIME::Base64;
use File::stat;
use WWW::Curl;
use WWW::Curl::Easy;
use Encode qw(encode decode);
use Data::Dumper;

$AppConfig::callerEnv = 'BACKGROUND';
$AppConfig::traceLogFile = 'dashboard.log';
$AppConfig::displayHeader = 0;

my $dashboardPID;

my $selfPIDFile;
my $selfPID;
my $at;
my $dhbVersion;
my $grpName = '';
my $lbs = '';
my $uname = '';
my $alarmintvl = 3;

my $wsport= '443';

#*****************************************************************************************************
# Subroutine			: init
# Objective				: Config and start the dashboard service
# Added By				: Yogesh Kumar
#****************************************************************************************************/
sub init {
	$0 = 'IDrive:dashboard:WB';

	$dashboardPID = sprintf("%d%d", getppid(), $$);

	Common::loadAppPath();
	exit(1) unless Common::loadServicePath();

	$selfPIDFile = getCatfile(getServicePath(), $AppConfig::userProfilePath, $AppConfig::mcUser);
	exit(1) unless (-d $selfPIDFile);

	$selfPIDFile = getCatfile($selfPIDFile, 'dashboard.pid');

	my $firstTime = 1;
	my $retryAttempts = 1;
	while(1) {
		$selfPID = (-f $selfPIDFile and getFileContents($selfPIDFile)) || -1;
		end() if ($$ != $selfPID);

		if (-f Common::getCatfile(Common::getAppPath(), 'debug.enable')) {
			unless ($AppConfig::debug) {
				$AppConfig::debug = 1;
				Common::traceLog('enabling debug mode');
			}
		}
		elsif ($AppConfig::debug) {
			$AppConfig::debug = 0;
			Common::traceLog('disabling debug mode');
		}

		unless (Common::loadServicePath() and Common::loadUsername()) {
			Common::traceLog('failed to load service path/username');
			stopDashboardRoutines();
			sleep(3);
			next;
		}

		if ($Idrivelib::VERSION ne $AppConfig::staticPerlVersion) {
			Common::traceLog('Dashboard version mismatch, please update to latest');
			unlink($selfPIDFile);
			exit 1;
		}

		unless (Common::loadUserConfiguration() == 1) {
			Common::traceLog('failed to load userconfig');
			stopDashboardRoutines();
			sleep(3);
			next;
		}

		if (getUserConfiguration('RMWS') ne 'yes') {
			Common::traceLog('No RMWS');
			last;
		}

		if (getUserConfiguration('DELCOMPUTER') eq 'D_1') {
			Common::traceLog('This computer is deleted');
			stopDashboardRoutines();
			sleep(3);
			next;
		}

		if (getUserConfiguration('UPTIME') eq '') {
			my $uptimeCmd = Common::updateLocaleCmd('who -b');
			my $uptime = `$uptimeCmd`;
			chomp($uptime);
			$uptime =~ s/system boot//;
			$uptime =~ s/^\s+//;
			setUserConfiguration('UPTIME', $uptime);
			saveUserConfiguration(0);
		}
		elsif ($firstTime and (getUserConfiguration('DEDUP') eq 'on')) {
			my $uptimeCmd = Common::updateLocaleCmd('who -b');
			my $uptime = `$uptimeCmd`;
			chomp($uptime);
			$uptime =~ s/system boot//;
			$uptime =~ s/^\s+//;
			if (getUserConfiguration('UPTIME') ne $uptime) {
				my $uie = sprintf("date -d'%s' +%%s", $uptime);
				$uie = Common::updateLocaleCmd($uie);
				$uie = `$uie`;
				chomp($uie);
				if ((time() - $uie) >= 604800) {
					my @devices = Common::fetchAllDevices();
					unless (Common::findMyDevice(\@devices)) {
						Common::traceLog('backup_location_is_adopted_by_another_machine');
						setUserConfiguration('BACKUPLOCATION', '');
						saveUserConfiguration(0, 1);
						Common::loadCrontab();
						Common::setCrontab('otherInfo', 'settings', {'status' => 'INACTIVE'}, ' ');
						Common::saveCrontab(0);
						end();
					}
				}

				setUserConfiguration('UPTIME', $uptime);
				saveUserConfiguration(0, 1);
				my $cmd = sprintf("%s %s 1 0", $AppConfig::perlBin, Common::getScript('logout', 1));
				$cmd = Common::updateLocaleCmd($cmd);
				`$cmd`;
			}
			$firstTime = 0;
		}

		# TODO: Re-Check
		$dhbVersion = 2;

		my $today = (localtime())[3];
		my %data  = ();

		# TODO: Re-Check
#		unless (getRemoteManageIP()) {
#debug('notify update remote manage ip ' . __LINE__);
#			%data = (
#				'content' => {
#					'channel' => 'update_remote_manage_ip',
#					'notification_value' => ''
#				}
#			);
#			my $ipStatus = startActivity(\%data, undef, 1);
#			if ($ipStatus == 1) {
#				Common::traceLog('Updated remote manage ip, re-loading dashboard');
#				stopDashboardRoutines();
#				next;
#			}
#			else {
#				Common::traceLog('Failed to load remote manage ip');
#				end();
#			}
#		}

		Common::traceLog('initDashboardRoutines');

		unless (loadAccessToken()) {
			Common::traceLog('failed to load access token');
			if ($retryAttempts < 5) {
				$retryAttempts += 1;
				sleep(60);
				next;
			}
			else {
				stopDashboardRoutines();
				end();
			}
		}

		if (isDashboardDeleted()) {
			Common::traceLog('This device from dashboard is deleted');
			end();
		}

		unless(loadNS()) {
			Common::traceLog('Failed to load notifications');
			stopDashboardRoutines();
			sleep(3);
			next;
		}

		if (getNS('update_device_info')) {
			if (replaceDevice(getNS('update_device_info'))) {
				my $nsFile = Common::getNSFile();
				my $nsfh;
				loadNS();
				if (open($nsfh, '+<', $nsFile)) {
					unless (flock($nsfh, LOCK_EX)) {
						traceLog("Cannot lock file $nsFile $!\n");
						close($nsfh);
						sleep(3);
						next;
					}
				}
				else {
					traceLog("Cannot open file $nsFile $!\n");
					sleep(3);
					next;
				}

				deleteNS('update_device_info');

				saveNS($nsfh);
				close($nsfh);
			}
		}

		unless (loadGroupNames()) {
			Common::traceLog('failed to load group names');
			stopDashboardRoutines();
			sleep(3);
			next;
		}

		unless (register2()) {
			Common::traceLog('failed to register this machine');
			stopDashboardRoutines();
			sleep(3);
			next;
		}

		$uname = getUsername();

		eval {
			fetchPropSettings2();
			watchDashboardLoginActivity2();
		} or do {
			if ($@) {
				Common::traceLog("Exception: $@");
			}
			else {
				Common::traceLog('Uncaught exception');
			}
		};
sleep(($alarmintvl + 2)); # Wait for alarm to Complete.
sleep(6);
next;
die "\n";

# TODO: Fix
#			if (getNS('update_remote_manage_ip') ne $today) {
#debug('notify update remote manage ip ' . __LINE__);
#				%data = (
#					'content' => {
#						'channel' => 'update_remote_manage_ip',
#						'notification_value' => ''
#					}
#				);
#				my $ipStatus = startActivity(\%data, undef, 1);
#				if ($ipStatus > 0) {
#					loadNotifications() and setNotification('update_remote_manage_ip', "$today") and saveNotifications();
#					$notifications{'update_remote_manage_ip'} = "$today";
#					if ($ipStatus == 1) {
#						stopDashboardRoutines();
#						last;
#					}
#				}
#				else {
#					$notifications{'update_remote_manage_ip'} = Common::getNotifications('update_remote_manage_ip');
#				}
#			}

	}

	return TRUE;
}

#*****************************************************************************************************
# Subroutine : request2
# In Param   : HASH
# Out Param  : HASH
# Objective  : To exchange data between client & server
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub request2 {
	my $dashboardConn = IO::Socket::SSL->new(
		PeerAddr => getRemoteManageIP(),
		PeerPort => "wss($wsport)",
		Proto => 'tcp',
		SSL_ca_file => getCatfile(Common::getAppPath(), 'ca-certificates.crt'),
	) or (Common::traceLog("Failed to create a dashboard connection: $@") and return FALSE);

	my $reqParams = $_[0];
	my $resData;
	my $client = Protocol::WebSocket::Client->new(url => "wss://$_[0]->{url}:$_[0]->{port}/$_[0]->{path}");
	$client->{hs}->{req}->{'origin'} = 'https://www.idrive.com';
	unless (exists $_[0]->{'headers'}) {
		$client->{hs}->{req}->{headers} = ['client', 'a9f6ca87a786', 'st', Idrivelib::get_dashboard_params({101=>$at},1,0)->{'data'}{'st'}];
	}
	else {
		$client->{hs}->{req}->{headers} = $_[0]->{'headers'};
	}
debug(Dumper('Headers: ', $_[0], $_[0]->{url}, $client->{hs}->{req}->{headers}));

	$client->on(
		write => sub {
			my $c = shift;
			my ($data) = @_;
			syswrite $dashboardConn, $data if ($dashboardConn->connected);
		}
	);

	$client->on(
		connect => sub {
			my $c = shift;

debug('connected');
			if (exists $reqParams->{'data'}) {
#print Dumper('connected', $reqParams->{'data'});
#				$c->write($reqParams->{'data'});
			}
		}
	);

	$client->on(
		error => sub {
			my $c = shift;
			my ($errorMSG) = @_;

			# TODO: Error Handling
debug('error');
			Common::traceLog("Error on websocket: $errorMSG");
			$dashboardConn->close;
		}
	);

	$client->on(
		read => sub {
			my $c = shift;
			my ($data) = @_;
			$resData = $data;
#print Dumper('read recived', $data);
		}
	);

	$client->connect;
	if (exists $reqParams->{'blocking'} and $reqParams->{'blocking'}) {
		while($dashboardConn->connected) {
			my $recvData;
			my $bytesRead = sysread $dashboardConn, $recvData, 16384;

			unless (defined $bytesRead) {
				Common::traceLog("sysread on dashboard socket failed: $!");
				return {
					STATUS => FAILURE,
				}
			}

			if ($bytesRead == 0) {
				Common::traceLog("dashboard websocket connection terminated");

				return {
					STATUS => FAILURE,
				}
			}

debug(Dumper('1-recvData', $recvData));
			$resData = '';
			$client->read($recvData);

			next unless($resData);
			my $rd;
			eval {
				$rd = from_json(decode_base64($resData));
				1;
			} or do {
debug("Exception: $@") if ($@);
				return {
					STATUS => FAILURE,
					DATA => $resData
				}
			};
			if (exists $rd->{'channeltype'} and $rd->{'channeltype'} eq 'timeout') {
				$client->write($reqParams->{'data'});
				next if ($reqParams->{'blocking'} eq 1);
				sleep(1);
			}

			$dashboardConn->close();
			$client->disconnect;
			return {
				STATUS => SUCCESS,
				DATA => from_json(decode_base64($resData))
			};
		}
		return {
			STATUS => FAILURE,
		};
	}

	while(!$client->{hs}->is_done) {
		my $recvData;
		my $bytesRead = sysread $dashboardConn, $recvData, 16384;

debug(Dumper('read: ', $bytesRead, $recvData));
		unless (defined $bytesRead) {
			Common::traceLog("sysread on dashboard socket failed: $!");
			return {
				STATUS => FAILURE,
			}
		}

		if ($bytesRead == 0) {
			Common::traceLog("dashboard websocket connection terminated");
			return {
				STATUS => FAILURE,
			}
		}

debug(Dumper('recvData', $recvData));
		$client->read($recvData);
	}

	my $alarm_handler = sub {
debug('ping');
		if ($dashboardConn->connected) {
			$client->write('eyJjaGFubmVsdHlwZSI6ImhlYXJ0YmVhdCIsImNvbnRlbnQiOnt9fQ==');
			alarm($alarmintvl);
		}
	};

	my $sigset = POSIX::SigSet->new(SIGALRM);
	my $sa_alarm = POSIX::SigAction->new($alarm_handler, $sigset, SA_RESTART);
	sigaction(SIGALRM, $sa_alarm);
	alarm(3);

	my $set = IO::Select->new($dashboardConn);

	my $t = time();
	while($dashboardConn->connected) {
debug('Reading again');
		my ($ready) = IO::Select->select($set, undef, undef, 5);
debug('Read socket');

		foreach my $readyDD (@$ready) {
			my $recvData;
			my $bytesRead = sysread $readyDD, $recvData, 16384;

			unless (defined $bytesRead) {
debug("sysread on dashboard socket failed: $!");
				Common::traceLog("sysread on dashboard socket failed: $!");
				$dashboardConn->close();
				$client->disconnect;
				return {
					STATUS => FAILURE,
				}
			}

			if ($bytesRead == 0) {
debug('dashboard websocket connection terminated');
				Common::traceLog("dashboard websocket connection terminated");
				$dashboardConn->close();
				$client->disconnect;
				return {
					STATUS => FAILURE,
				}
			}

			$resData = '';
			$client->read($recvData);

			next unless($resData);

			if ($recvData eq 'eyJjaGFubmVsdHlwZSI6ImhlYXJ0YmVhdCIsImNvbnRlbnQiOnt9fQ==') {
				next;
			}
debug(Dumper('received: ', $recvData));

			my $fd = startActivity2($recvData);
			if ($fd and not looks_like_number($fd)) {
				$client->write($fd);
debug(Dumper('Send: ', $fd));
			}
		}

		if ((time() - $t) >= 5) {
			$t = time();
			unless (Common::loadServicePath() and Common::loadUsername()) {
				$dashboardConn->close();
				$client->disconnect;
				Common::traceLog('service stopping. failed to load service path or username.');
				return {
					STATUS => FAILURE,
				}
			}
			if (('' ne getUsername()) and ($uname ne getUsername())) {
				$dashboardConn->close();
				$client->disconnect;
				Common::traceLog('service stopping. failed to load username or user signed off.');
				return {
					STATUS => FAILURE,
				}
			}

debug('syncUpdates');
			syncUpdates($client);
		}
	}
}

#*****************************************************************************************************
# Subroutine			: debug
# Objective				: Wrapper for Common::traceLog
# Added By				: Yogesh Kumar
#****************************************************************************************************/
sub debug {
	if ($AppConfig::debug) {
		my $msg = "DA:DEBUG: ";
		$msg .= join('', @_);
		Common::traceLog($msg);
	}
	return 1;
}

#*****************************************************************************************************
# Subroutine			: deleteComputer
# Objective			: Reset schedled tasks, backupset and logout the user.
# Added By			: Yogesh Kumar
#****************************************************************************************************/
sub deleteComputer {
	setUserConfiguration('DELCOMPUTER', 'D_1');
	saveUserConfiguration(0);
	Common::deleteBackupDevice(1);
	end();
}

#*****************************************************************************************************
# Subroutine			: isDashboardDeleted
# Objective			: Check if this device is deleted from dashboard
# Added By			: Yogesh Kumar
#****************************************************************************************************/
sub isDashboardDeleted {
	return FALSE if (getUserConfiguration('DELCOMPUTER') eq 'S_1');
	my $r = {
		channeltype => 'read',
		table => 'userinformation',
		operation => 'exact',
		cname => getUsername(),
		aname => getParentUsername(),
		mid => getParentUsername(),
		pname => getParentUsername(),
	};

	my $resData = request2({
		url => getRemoteManageIP(),
		port=> $wsport,
		path=> ('ws/evsnotifydb/' . encode_base64(getParentUsername(), '') . '/'),
		data=> encode_base64(to_json($r), ''),
		blocking=> 1
	});
	foreach my $m (@{$resData->{'DATA'}{'content'}}) {
		if (($m->{'os'} eq 'linux') and ($m->{'AddField4'} eq '1') and
			($m->{'mid'} eq Common::getMachineUID(0)) and
			($m->{'hname'} eq hostname) and
			($m->{'pname'} eq getMachineUser()) and
			($m->{'cname'} eq getUsername())) {
			deleteComputer();

			return TRUE;
		}
	}

	return FALSE;
}

#*****************************************************************************************************
# Subroutine			: loadAccessToken
# Objective				: Load access token
# Added By				: Yogesh Kumar
#****************************************************************************************************/
sub loadAccessToken {
debug('loadAccessToken');
	my $token = getRemoteAccessToken();

	return 0 unless $token;
	$at = Idrivelib::get_atd($token);

	return 1;
}

#*****************************************************************************************************
# Subroutine : register2
# In Param   : HASH(optional)
# Out Param  : BOOLEAN
# Objective  : Register this computer for dashboard service
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub register2 {
	my $host = getRemoteManageIP();
	my $isDedup = getUserConfiguration('DEDUP');
	my $backupLocation = getUserConfiguration('BACKUPLOCATION');
	my $rd = $AppConfig::releasedate;
	$rd =~ s/-/\//g;

	if ($isDedup eq "on") {
		$backupLocation = (split("#", $backupLocation))[1];
	}

	my $r = {
		channeltype => 'insert',
		table => 'userinformation',
		cname => getUsername(),
		aname => getParentUsername(),
		mid => Common::getMachineUID(0),
		pname => getMachineUser(),
		content => [
			{
				hname => hostname,
				nname => $backupLocation,
				os => 'linux',
				ver => 'evs006',
				dk => getUserConfiguration('DDA'),
				blc => getUserConfiguration('BDA'),
				appver => ($AppConfig::version . '_' . $rd),
				AddField4 => '0'
			}
		]
	};

	if (defined $_[0]) {
		foreach my $key (keys %{$_[0]}) {
			$r->{'content'}->[0]->{$key} = $_[0]->{$key}
		}
	}

	if (getUserConfiguration('DELCOMPUTER') eq 'S_1') {
		$r->{'content'}->[0]->{'AddField4'} = '0';
		setUserConfiguration('DELCOMPUTER', 'D_0');
		saveUserConfiguration(0, 1);
	}

	my $resData = request2({
			url => getRemoteManageIP(),
			port=> $wsport,
			path=> ('ws/evsnotifydb/' . encode_base64(getParentUsername(), '') . '/'),
			data=> encode_base64(to_json($r), ''),
			blocking=> 1
		});
debug(Dumper('Add/Update device info: ', $resData));

	return FALSE unless(ref $resData eq 'HASH');

	return FALSE if ($resData->{'STATUS'} eq FAILURE);

	return TRUE;
}

#*****************************************************************************************************
# Subroutine : replaceDevice
# In Param   : STRING
# Out Param  : BOOLEAN
# Objective  : Replace account settings from last accessed device.
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub replaceDevice {
	my @deviceInfo = split('-', $_[0]);
	$deviceInfo[0] =~ s/$AppConfig::deviceUIDPrefix//g;

	my ($ep, $d);
	$d = {
		channeltype => 'removeDevice',
		content => {
			mid => $deviceInfo[0],
			pname => $deviceInfo[2],
			did => $deviceInfo[1],
		}
	};
	if (getUserConfiguration('ADDITIONALACCOUNT') eq 'true') {
		$ep = (encode_base64(getParentUsername(), '') . '/' . encode_base64(getUsername(), ''));
	}
	else {
		$ep = encode_base64(getUsername(), '');
	}
	my $resData = request2({
		url => getRemoteManageIP(),
		port=> $wsport,
		path=> ('ws/evsnotify/' . $ep . '/' . encode_base64(($deviceInfo[0] . '_' . $deviceInfo[2]), '') . '/'),
		headers=> [
			'client', 'a9f6ca87a786',
			'st', Idrivelib::get_dashboard_params({101=>$at},1,0)->{'data'}{'st'},
			'cname', getUsername(),
			'aname', getParentUsername(),
			'pname', $deviceInfo[2],
			'mid', $deviceInfo[0],
			'cnameb64', encode_base64(getUsername(), ''),
			'anameb64', encode_base64(getParentUsername(), '')
		],
		data => encode_base64(to_json($d), ''),
		blocking=> 2
	});

	return FALSE unless ($deviceInfo[3] eq 'y');

	my $r = {
		channeltype => 'read',
		table => 'all',
		operation => 'custom',
		cname => getUsername(),
		aname => getParentUsername(),
		pname => $deviceInfo[2],
		mid => $deviceInfo[0],
	};

	$resData = request2({
		url => getRemoteManageIP(),
		port=> $wsport,
		path=> ('ws/evsnotifydb/' . encode_base64(getParentUsername(), '') . '/'),
		data=> encode_base64(to_json($r), ''),
		blocking=> 1
	});

	if (exists $resData->{'STATUS'} and $resData->{'STATUS'} eq SUCCESS) {
		if (applyPropSettings($resData->{'DATA'}{'content'}, 1, $deviceInfo[2])) {
			return TRUE;
		}
	}
	return FALSE;
}

#*****************************************************************************************************
# Subroutine : loadGroupNames
# In Param   : -
# Out Param  : BOOLEAN
# Objective  : Load this user's group names
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub loadGroupNames {
	my $entAC = lc(getUserConfiguration('PLANTYPE') . getUserConfiguration('PLANSPECIAL'));
	if (getUserConfiguration('PARENTACCOUNT') and
					((getUserConfiguration('ADDITIONALACCOUNT') eq 'true') or ($entAC =~ /business/))) {
		my $grp = Common::makeRequest(11, [
			getUsername(),
			Idrivelib::get_sso_auth(&Common::getPdata(getUsername())),
			Idrivelib::get_sso_auth(getUsername())
		]);
		if ($grp->{'STATUS'} eq SUCCESS) {
			$grp = from_json($grp->{'DATA'});
			if (exists $grp->{'grps'}) {
				$grpName = $grp->{'grps'};
				return TRUE;
			}
			else {
				debug(Dumper('load groupnames: ', $grp));
			}
		}
	}
	else {
		return TRUE;
	}

	return FALSE;
}

#*****************************************************************************************************
# Subroutine : applyPropSettings
# In Param   : HASH, BOOLEAN
# Out Param  : BOOLEAN
# Objective  : Apply & save prop settings.
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub applyPropSettings {
	my $ps = Common::getPropSettings('master');
	$_[1] = (defined($_[1]) ? $_[1] : 0);
	my $tv;

	if (exists $_[0]->{'settings'}) {
		my $settings = {
			channeltype => 'settings',
			grp => 'all'
		};
		foreach my $item (keys %{$_[0]->{'settings'}->[0]}) {
			if (exists $DashboardUtility::propFields{$item} and
					($_[0]->{'settings'}->[0]->{$item} ne '')) {
				eval {
					$tv = from_json($_[0]->{'settings'}->[0]->{$item});
				};
				unless ($@) {
					if (exists $ps->{'pf'} and exists $ps->{'pf'}{$item} and
							int($ps->{'pf'}{$item}{'time'}) >= int($tv->{'time'})) {
						next;
					}
					$ps->{'pf'}{$item}{'time'} = $tv->{'time'};
					$ps->{'ismodified'} = 1 unless($ps->{'ismodified'});
				};
				$settings->{'content'}{$item} = $_[0]->{'settings'}->[0]->{$item};
			}
		}
		if (exists $settings->{'content'}) {
			startActivity2($settings, 1);
		}
	}

	if (exists $_[0]->{'backupset'}) {
		foreach my $item (@{$_[0]->{'backupset'}}) {
			if (($item->{'bkpsetname'} eq 'Default BackupSet_LINUX') and exists $item->{'bkpcontent'}) {
				startActivity2({
					channeltype => 'defaultbackupset',
					content => [{
						bkpcontent => $item->{'bkpcontent'},
					}],
					grp => 'all',
					ps => $ps
				}, 1);
				next;
			}
			elsif (($item->{'bkpsetname'} eq ('LocalBackupSet_LINUX')) and exists $item->{'bkpcontent'}) {
				startActivity2({
					channeltype => 'localbackupset',
					content => [{
						bkpcontent => $item->{'bkpcontent'},
					}],
					grp => 'all',
					ps => $ps
				}, 1);
				next;
			}
			elsif ($_[1] and ($item->{'bkpsetname'} eq ('Default BackupSet_' . $_[2])) and exists $item->{'bkpcontent'}) {
				next if ($item->{'bkpcontent'} eq 'NA');
				startActivity2({
					channeltype => 'defaultbackupset',
					content => [{
						bkpcontent => ("{\"value\": $item->{'bkpcontent'}}"),
					}],
					grp => 'all'
				}, 1);
				next;
			}
			elsif ($_[1] and ($item->{'bkpsetname'} eq ('LocalBackupSet_' . $_[2])) and exists $item->{'bkpcontent'}) {
				next if ($item->{'bkpcontent'} eq 'NA');
				startActivity2({
					channeltype => 'localbackupset',
					content => [{
						bkpcontent => ("{\"value\": $item->{'bkpcontent'}}"),
					}],
					grp => 'all'
				}, 1);
				next;
			}
		}
	}

	if (exists $_[0]->{'scheduler'}) {
		my $content = [];
		my $bkpsetname = '';
		foreach my $item (keys %{$_[0]->{'scheduler'}->[0]}) {
			if ($_[0]->{'scheduler'}->[0]->{$item} ne '') {
				eval {
					$tv = from_json($_[0]->{'scheduler'}->[0]->{$item});
				};
				unless ($@) {
					if ($bkpsetname ne $_[0]->{'scheduler'}->[0]->{'bksetname'}) {
						$bkpsetname = $_[0]->{'scheduler'}->[0]->{'bksetname'};
					}
					if (exists $ps->{'pf'} and exists $ps->{'pf'}{$bkpsetname} and exists $ps->{'pf'}{$bkpsetname}{$item} and
							int($ps->{'pf'}{$bkpsetname}{$item}{'time'}) >= int($tv->{'time'})) {
						next;
					}
					$ps->{'pf'}{$bkpsetname}{$item}{'time'} = $tv->{'time'};
					$ps->{'ismodified'} = 1 unless($ps->{'ismodified'});
				}
				$content->[0]->{$item} = $_[0]->{'scheduler'}->[0]->{$item};
			}
		}
		foreach my $item (keys %{$_[0]->{'scheduler'}->[1]}) {
			if ($_[0]->{'scheduler'}->[1]->{$item} ne '') {
				eval {
					$tv = from_json($_[0]->{'scheduler'}->[1]->{$item});
				};
				unless ($@) {
					if ($bkpsetname ne $_[0]->{'scheduler'}->[1]->{'bksetname'}) {
						$bkpsetname = $_[0]->{'scheduler'}->[1]->{'bksetname'};
					}
					if (exists $ps->{'pf'} and exists $ps->{'pf'}{$bkpsetname} and exists $ps->{'pf'}{$bkpsetname}{$item} and
							int($ps->{'pf'}{$bkpsetname}{$item}{'time'}) >= int($tv->{'time'})) {
						next;
					}
					$ps->{'pf'}{$bkpsetname}{$item}{'time'} = $tv->{'time'};
					$ps->{'ismodified'} = 1 unless($ps->{'ismodified'});
				};
				$content->[1]->{$item} = $_[0]->{'scheduler'}->[1]->{$item};
			}
		}
		startActivity(DashboardUtility::parseSch($content, getUsername(), getMachineUser()), undef, 1, 1);
	}

	if (exists $_[0]->{'config'}) {
		if (exists $_[0]->{'config'}->[0]->{'lock'} and ($_[0]->{'config'}->[0]->{'lock'} ne '')) {
			DashboardUtility::updateLockSettings($_[0]->{'config'}->[0]->{'lock'}, $ps);
		}
		elsif (exists $_[0]->{'config'}->[0]->{'lockinfo'} and ($_[0]->{'config'}->[0]->{'lockinfo'} ne '')) {
			DashboardUtility::updateLockSettings($_[0]->{'config'}->[0]->{'lockinfo'}, $ps);
		}

		if ($_[1]) {
			startActivity(DashboardUtility::parseArchiveCleanup2($_[0]->{'config'}->[0], getUsername()), undef, 1, 1);
		}
		else {
			my $nc = 0;
			eval {
				$tv = from_json($_[0]->{'config'}->[0]->{'arch_cleanup_checked'});
			};
			unless ($@) {
				if (exists $ps->{'pf'} and exists $ps->{'pf'}{'acc'} and
						int($ps->{'pf'}{'acc'}{'time'}) >= int($tv->{'time'})) {
					$nc = 1;
				}
				else {
					$ps->{'pf'}{'acc'}{'time'} = $tv->{'time'};
					$ps->{'ismodified'} = 1 unless($ps->{'ismodified'});
				}
			}
			unless ($nc) {
				startActivity(DashboardUtility::parseArchiveCleanup2($_[0]->{'config'}, getUsername()), undef, 1, 1);
			}
		}
	}
	if (exists $ps->{'ismodified'}) {
		delete $ps->{'ismodified'};
		Common::fileWrite(Common::getPropSettingsFile('master'), to_json($ps));
	}

	return TRUE;
}

#*****************************************************************************************************
# Subroutine : fetchPropSettings2
# In Param   : -
# Out Param  : BOOLEAN
# Objective  : fetch prop settings from dashboard.
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub fetchPropSettings2 {
	my $host = getRemoteManageIP();
	my $isDedup = getUserConfiguration('DEDUP');
	my $backupLocation = getUserConfiguration('BACKUPLOCATION');

	if ($isDedup eq "on") {
		$backupLocation = (split("#", $backupLocation))[1];
	}

	my $r = {
		channeltype => 'read',
		table => 'all',
		operation => 'custom',
		cname => getParentUsername(),
		aname => getParentUsername(),
		mid => getParentUsername(),
		pname => getParentUsername(),
	};

	my $resData = request2({
		url => getRemoteManageIP(),
		port=> $wsport,
		path=> ('ws/evsnotifydb/' . encode_base64(getParentUsername(), '') . '/prop/'),
		data=> encode_base64(to_json($r), ''),
		blocking=> 1
	});
debug(Dumper('1prop settings: ', $resData));

	if (exists $resData->{'DATA'}{'content'}) {
		applyPropSettings($resData->{'DATA'}{'content'});
	}

	my $entAC = lc(getUserConfiguration('PLANTYPE') . getUserConfiguration('PLANSPECIAL'));
	if (getUserConfiguration('PARENTACCOUNT') and ((getUserConfiguration('ADDITIONALACCOUNT') eq 'true') or ($entAC =~ /business/))) {
		$r = {
			channeltype => 'read',
			table => 'all',
			operation => 'custom',
			cname => getUsername(),
			aname => getParentUsername(),
			mid => getParentUsername(),
			pname => getParentUsername(),
		};

		$resData = request2({
			url => getRemoteManageIP(),
			port=> $wsport,
			path=> ('ws/evsnotifydb/' . encode_base64(getParentUsername(), '') . '/prop/'),
			data=> encode_base64(to_json($r), ''),
			blocking=> 1
		});
debug(Dumper('2prop settings: ', $resData));

		if (exists $resData->{'DATA'}{'content'}) {
			applyPropSettings($resData->{'DATA'}{'content'});
		}
	}

	return TRUE;

}

#*****************************************************************************************************
# Subroutine : getSysInfo
# In Param   : -
# Out Param  : HASH
# Objective  : Get system information
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub getSysInfo {
	if ($dhbVersion == 2) {
		return {
			ip                => Common::getIPAddr(),
			version           => $AppConfig::version,
			bkploc            => Common::getBackupDeviceName(),
			drive             => getUserConfiguration('LOCALMOUNTPOINT'),
			isUpdateAvailable => Common::isLatest()
		}
	}

	return {
		ip             => Common::getIPAddr(),
		version        => $AppConfig::version,
		backuplocation => Common::getBackupDeviceName(),
		hasupdate      => Common::isLatest()
	}
}

#*****************************************************************************************************
# Subroutine : saveChangesToDHB
# In Param   : STRING
# Out Param  : ARRAY or STRING
# Objective  : Save local modifications to DHB
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub saveChangesToDHB {
	my $r = {
		channeltype => 'insert',
		table => $_[0],
		content => $_[1],
		cname => getUsername(),
		aname => getParentUsername(),
		mid => Common::getMachineUID(0),
		pname => getMachineUser(),
	};

	my $resData = request2({
		url => getRemoteManageIP(),
		port=> $wsport,
		path=> ('ws/evsnotifydb/' . encode_base64(getParentUsername(), '') . '/'),
		data=> encode_base64(to_json($r), ''),
		blocking=> 1
	});
debug(Dumper('push data: ', $r, 'status: ', $resData));
}

#*****************************************************************************************************
# Subroutine : getFileSetContent
# In Param   : STRING
# Out Param  : ARRAY or STRING
# Objective  : Get file set contents
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub getFileSetContent {
	my $bsf = Common::getJobsPath($_[0], 'file');
	my $recal = $_[1] || 0;

	unless (-f "$bsf.json" and -s "$bsf.json" > 0) {
		return [];
	}

	my $bs = from_json(getFileContents("$bsf.json"));

	if ($recal) {
		my $bs2 = {};
		foreach (keys %{$bs}) {
			$bs2->{$_} = {
				size => -1,
				ts => '',
				filecount => -1,
				type => $bs->{$_}->{'type'}
			}
		}
		Common::fileWrite2("$bsf.json", JSON::to_json($bs2));
		$bs = $bs2;
		system(
			Common::updateLocaleCmd(
				$AppConfig::perlBin . " " . Common::getScript('utility', 1) ." CALCULATEBACKUPSETSIZE $_[0] 2>/dev/null &"
			)
		);
	}

	return [map{{path => $_, size => $bs->{$_}->{'size'}, type => $bs->{$_}->{'type'}, count => $bs->{$_}->{'filecount'}}} keys %{$bs}];

}

#*****************************************************************************************************
# Subroutine : saveFileSetContent
# In Param   : STRING
# Out Param  : ARRAY or STRING
# Objective  : Save file set contents
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub saveFileSetContent {
	my $bsf = Common::getJobsPath($_[0], 'file');
	open(my $bsfh, '>', $bsf) or return 0;
	my %backupsetsizes = (-f "$bsf.json")? %{JSON::from_json(getFileContents("$bsf.json"))} : ();
	my $calculateSize = FALSE;

	my %backupSet;
	if ($_[0] =~ /backup/) {
		my @itemsarr = ((exists $_[1]->{'grp'}) ? keys %backupsetsizes : ());
		foreach my $key (keys %{$_[1]->{'files'}}) {
				if (utf8::is_utf8($key)) {
				utf8::downgrade($key);
			}
			if (substr($key, 0, 2) eq '~/') {
				my $userHomeDirCmd = Common::updateLocaleCmd('echo ~');
				my $userHomeDir = `$userHomeDirCmd`;
				chomp($userHomeDir);
				push @itemsarr, ("$userHomeDir/" . substr($key, 2));
			}
			else {
				push @itemsarr, $key;
			}
		}
		@itemsarr = Common::verifyEditedFileContent(\@itemsarr);
		if (scalar(@itemsarr) > 0) {
			%backupSet = Common::getLocalDataWithType(\@itemsarr, 'backup');
			%backupSet = Common::skipChildIfParentDirExists(\%backupSet);
		}
		else {
			%backupSet= ();
		}
	}
	else {
		%backupSet = %{$_[1]->{'files'}};
	}

	my %backupSetInfo;
	my $k = '';
	foreach my $key (keys %backupSet) {
		$k = $key;
		$k =~ s/\/$// unless(exists($_[1]->{'files'}{$k}));

		print $bsfh "$key\n";
		if (exists $backupsetsizes{$key}) {
			$backupSetInfo{$key} = $backupsetsizes{$key};
			$calculateSize = TRUE if ($backupsetsizes{$key}{'size'} == -1);
		}
		else {
			$calculateSize = TRUE if ($_[0] =~ /backup/);
			$backupSetInfo{$key} = {
				'size' => (exists $_[1]->{'files'}{$k}{'size'} ? $_[1]->{'files'}{$k}{'size'} : -1),
				'ts'   => '',
				'filecount' => '-1',
				'type' => $_[1]->{'files'}{$k}{'type'}
			}
		}
	}
	Common::fileWrite2("$bsf.json", JSON::to_json(\%backupSetInfo));
	close($bsfh);

	if ($calculateSize) {
		system(
			Common::updateLocaleCmd(
				$AppConfig::perlBin . " " . Common::getScript('utility', 1) ." CALCULATEBACKUPSETSIZE $_[0] 2>/dev/null &"
			)
		);
	}

	return TRUE;
}

#*****************************************************************************************************
# Subroutine : startJob
# In Param   : STRING, STRING
# Out Param  : HASH
# Objective  : Start backup, localbackup or restore jobs
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub startJob {
	if ($_[0] eq 'backup_scripts') {
		my %ArchJobDetails = Common::getRunningJobs('archive');

		if (%ArchJobDetails) {
			return encode_base64(to_json({
				channeltype => 'notify',
				bid => 'dummy',
				content => {
					type => lc(FAILURE),
					msg => 'archive cleanup is in progress please try again later'
				}
			}), '');
		}
	}

	my $cmd = ("$AppConfig::perlBin " . Common::getScript($_[0], 1));
	$cmd   .= (" $_[1] " . getUsername() .  ' 1> /dev/null 2> /dev/null &');
	$cmd = Common::updateLocaleCmd($cmd);
debug("start job: $_[0]");
	unless (system($cmd) == 0) {
	}
	else {
	}

	return TRUE;
}

#*****************************************************************************************************
# Subroutine : stopJob
# In Param   : STRING
# Out Param  : HASH
# Objective  : Stop backup, localbackup or restore jobs
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub stopJob {
	unless (Common::isFileLocked(getCatfile(Common::getJobsPath($_[0]), 'pid.txt'))) {
		if (loadNS() and (getNS(sprintf("update_%s_progress", $_[0])) =~ /_Running_/)) {
			my $nv = getNS(sprintf("update_%s_progress", $_[0]));
			$nv =~ s/_Running_/_Aborted_/g;
			loadNotifications() and setNotification(sprintf("update_%s_progress", $_[0]), $nv) and saveNotifications();
		}
		return encode_base64(to_json({
			channeltype => 'notify',
			bid => 'dummy',
			content => {
				type => lc(FAILURE),
				msg => "$_[0] stopped"
			}
		}), '');
	}

	my $cmd = ("$AppConfig::perlBin " . Common::getScript('job_termination', 1));
	$cmd   .= (" $_[0] " . getUsername() . ' 1>/dev/null 2>/dev/null &');
	$cmd = Common::updateLocaleCmd($cmd);
debug("stop job: $_[0]\n cmd: $cmd");
	system($cmd);
}

#*****************************************************************************************************
# Subroutine : getProgressUpdates
# In Param   : STRING
# Out Param  : HASH
# Objective  : Get backup/restore progress details
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub getProgressUpdates {
	my $progressDetailsFile = getCatfile(Common::getJobsPath($_[0]), $AppConfig::progressDetailsFilePath);
	my $pidFile = getCatfile(Common::getJobsPath($_[0]), 'pid.txt');
	if (!Common::isFileLocked($pidFile, undef, 1) and ($_[1]->[1] eq 'Running')) {
		if (-f getCatfile(Common::getJobsPath($_[0]), $AppConfig::logPidFile)) {
			Common::checkAndRenameFileWithStatus(Common::getJobsPath($_[0]), $_[0]) if (-f $pidFile);
			return {};
		}

		loadNotifications() and setNotification(sprintf("update_%s_progress", $_[0]), "$_[1]->[0]_Aborted_$_[1]->[2]") and saveNotifications();
		unlink($pidFile) if (-f $pidFile);

		return {};
	}
	my @progressData = Common::getProgressDetails($progressDetailsFile);
	my $desc = '';
	my $prgtype = 1;

	if ($progressData[2] eq Common::getStringConstant('calculating') or $progressData[2] =~ /calculating/i) {
		$progressData[2] = 0;
	}

	unless ($progressData[2]) {
		$desc = 'MSG_PREP_FILE_LIST';
	}

	unless ($_[1]->[1] eq 'Running') {
		$desc = '?stop';
	}

	if ($_[0] eq 'backup') {
		if ($lbs ne "$_[1]->[0]_$_[1]->[1]_$_[1]->[2]") {
			$lbs = ("$_[1]->[0]_$_[1]->[1]_$_[1]->[2]");
			my $ps = 0;
			if ($_[1]->[1] eq 'Failure') {
				$ps = 1;
			}
			elsif ($_[1]->[1] eq 'Aborted') {
				$ps = 2;
			}
			elsif ($_[1]->[1] eq 'Running') {
				$ps = 3;
			}

			register2({
				lbs => ((int($_[1]->[0]) + $at) . '_' . $ps . '_0'),
				alert => (encode_base64(to_json([{
					type => '',
					errcode => ''
				}]), ''))
			});
		}
		if ($_[1]->[2] ne 'Manual') {
			$prgtype = 2;
		}
	}
	elsif ($_[0] eq 'localbackup') {
		$prgtype = 1;
	}
	elsif ($_[0] eq 'restore') {
		$prgtype = 3;
	}

	my %progressDetails = (
		channeltype => 'progress',
		bid => 'dummy',
		content => {
			desc => $desc,
			bkpSetName => $_[0],
			prgtype => $prgtype,
			opType => ucfirst($_[0]),
			status => $_[1]->[1],
		}
	);

	if ($progressData[2]) {
		$progressDetails{'content'}->{'type'} = (($progressData[0] =~ /^Full/) ? 1 : 2);
		$progressDetails{'content'}->{'fname'} = $progressData[4];
		$progressDetails{'content'}->{'totpers'} = int($progressData[1]/$progressData[2]*100);
		$progressDetails{'content'}->{'fsize'} = $progressData[5];
		$progressDetails{'content'}->{'cumsize'} = $progressData[1];
		$progressDetails{'content'}->{'totrfsize'} = $progressData[2];
		$progressDetails{'content'}->{'trfrate'} = $progressData[3];

		if ($progressDetails{'content'}->{'totpers'} > 100) {
			$progressDetails{'content'}->{'totpers'} = 100;
		}
	}

	return \%progressDetails;
}

#*****************************************************************************************************
# Subroutine : getLogs
# In Param   : -
# Out Param  : HASH or ARRAY
# Objective  : Start backup, localbackup or restore jobs
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub getLogs {
	my %data = ();
	my @d = ();
	my $l = ();
	my ($startDate, $endDate) = Common::getStartAndEndEpochTime(7);

	foreach my $job (keys %AppConfig::availableJobsSchema) {
		$l = Common::selectLogsBetween(undef,
		 	$startDate,
			$endDate,
			(Common::getJobsPath($job) . "/$AppConfig::logStatFile"));
		if ($dhbVersion == 2) {
			push(@d, (map{{
						optype   => $job,
						datetime => $l->FETCH($_)->{'datetime'} =~ s/\//-/gr,
						duration => Common::convert_seconds_to_hhmmss($l->FETCH($_)->{'duration'}),
						status   => $l->FETCH($_)->{'status'},
						files    => $l->FETCH($_)->{'filescount'},
						bkpfiles => $l->FETCH($_)->{'bkpfiles'},
						type     => 7,
						size     => $l->FETCH($_)->{'size'},
						filename => ("$_\_" . $l->FETCH($_)->{'status'})
					}} $l->Keys));
		}
		else {
			foreach($l->Keys) {
				$data{'logs'}{$_} = $l->FETCH($_);
				$data{'logs'}{$_}{'type'} = $job;
			}
			$data{'status'} = AppConfig::SUCCESS;
		}
	}

	if ($dhbVersion == 2) {
		return \@d;
	}
	else {
		return \%data;
	}
}

#*****************************************************************************************************
# Subroutine : getLog
# In Param   : -
# Out Param  : STRING, STRING
# Objective  : Get log summary
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub getLog {
	my %logData = ();
	my $logFile = getCatfile(Common::getJobsPath($_[0], 'logs'), $_[1]);

	if (-f $logFile) {
		my $logContentCmd = Common::updateLocaleCmd("tail -n30 '$logFile'");
		my @logContent = `$logContentCmd`;

		my $copyFileLists = 0;
		my $copySummary   = 0;

		$logData{'status'} = AppConfig::SUCCESS;

		foreach (@logContent) {
			if (!$copySummary and substr($_, 0, 8) eq 'Summary:') {
				$copySummary = 1;
			}
			elsif (!$copyFileLists and substr($_, 0, 1) eq '[') {
				$copyFileLists = 1;
			}

			if ($copySummary) {
				if ($_ =~ m/^Backup End Time/) {
					my @startTime = localtime((split('_', $_[1]))[0]);
					my $et = localtime(mktime(@startTime));
					$logData{'summary'} .= sprintf("Backup Start Time: %s\n", $et);
				}
				elsif ($_ =~ m/Restore End Time/) {
					my @startTime = localtime((split('_', $_[1]))[0]);
					my $et = localtime(mktime(@startTime));
					$logData{'summary'} .= sprintf("Restore Start Time: %s\n", $et);
				}
				elsif ($_ =~ m/End Time/) {
					my @startTime = localtime((split('_', $_[1]))[0]);
					my $et = localtime(mktime(@startTime));
					$logData{'summary'} .= sprintf("Start Time: %s\n", $et);
				}

				$logData{'summary'} .= $_;
			}
			elsif ($copyFileLists) {
				# $logData{'details'} .= $_;
			}
		}

		# my $notemsg = Common::getLocaleString('files_in_trash_may_get_restored_notice');
		# $logData{'summary'} =~ s/$notemsg//gs;

		my $logheadCmd = Common::updateLocaleCmd("head -n20 '$logFile'");
		my @loghead = `$logheadCmd`;
		$logData{'details'}	= Common::getLocaleString('version_cc_label') . $AppConfig::version . "\n";
		$logData{'details'} .= Common::getLocaleString('release_date_cc_label') . $AppConfig::releasedate . "\n";
		foreach(@loghead) {
			last if (substr($_, 0, 8) eq 'Summary:');
			$logData{'details'} .= $_;
		}
	}

	return \%logData;
}

#*****************************************************************************************************
# Subroutine : getExcludeItems
# In Param   : STRING
# Out Param  : STRING
# Objective  : Get fully excluded files
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub getExcludeItems {
	my $ei = getCatfile(getUserProfilePath(), $_[0]);
	$ei .= '.info';
	my $files = '';
	if ((-f $ei) and !-z $ei) {
		my $c = getFileContents($ei, 'array');
		my $i = 0;
		foreach (@{$c}) {
			if (($i % 2) == 0) {
				$files .= "$_\\";
			}
			elsif ($_ eq 'enabled') {
				$files .= "1\r\n";
			}
			elsif ($_ eq 'disabled') {
				$files .= "0\r\n";
			}
			$i++;
		}

		if ($i) {
			$files =~ s/\r\n$//g;
		}
	}

	return $files;
}

#*****************************************************************************************************
# Subroutine : saveExcludeFiles
# In Param   : HASH
# Out Param  : BOOLEAN
# Objective  : Save file set contents posted from dashboard
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub saveExcludeFiles {
	my $fullExcludeListFile = getCatfile(getUserProfilePath(), $AppConfig::fullExcludeListFile);
	my $partialExcludeListFile = getCatfile(getUserProfilePath(), $AppConfig::partialExcludeListFile);
	my $regexExcludeListFile = getCatfile(getUserProfilePath(), $AppConfig::regexExcludeListFile);
	my $fileContent = '';

	if (exists $_[0]->{'settings'}{'fullExclude'}) {
		Common::fileWrite("$fullExcludeListFile.info", $_[0]->{'settings'}{'fullExclude'});
		foreach (split(/\n/, $_[0]->{'settings'}{'fullExclude'})) {
# TODO: ignore disabled item from *.txt file
			next if ($_ eq 'enabled' or $_ eq 'disabled');
			$fileContent .= "$_\n";
		}
		Common::fileWrite($fullExcludeListFile, $fileContent);
	}
	if (exists $_[0]->{'settings'}{'partialExclude'}) {
		$fileContent = '';
		Common::fileWrite("$partialExcludeListFile.info", $_[0]->{'settings'}{'partialExclude'});
		foreach (split(/\n/, $_[0]->{'settings'}{'partialExclude'})) {
# TODO: ignore disabled item from *.txt file
			next if ($_ eq 'enabled' or $_ eq 'disabled');
			$fileContent .= "$_\n";
		}
		Common::fileWrite($partialExcludeListFile, $fileContent);
	}
	if (exists $_[0]->{'settings'}{'regexExclude'}) {
		$fileContent = '';
		Common::fileWrite("$regexExcludeListFile.info", $_[0]->{'settings'}{'regexExclude'});
		foreach (split(/\n/, $_[0]->{'settings'}{'regexExclude'})) {
# TODO: ignore disabled item from *.txt file
			next if ($_ eq 'enabled' or $_ eq 'disabled');
			$fileContent .= "$_\n";
		}
		Common::fileWrite($regexExcludeListFile, $fileContent);
	}

	return TRUE;
}

#*****************************************************************************************************
# Subroutine : getScheduledJobs
# In Param   : STRING
# Out Param  : HASH
# Objective  : Get scheduled details to dashboard
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub getScheduledJobs {
	if (Common::loadCrontab(getUsername())) {
		my $ct = Common::getCrontab();
		if (exists $ct->{$AppConfig::mcUser} and exists $ct->{$AppConfig::mcUser}{getUsername()}) {
			if ($dhbVersion == 2) {
				return DashboardUtility::parseSchForDHB($ct->{$AppConfig::mcUser}{getUsername()}, $_[0]);
			}
			else {
				return {
					getUsername() => $ct->{$AppConfig::mcUser}{getUsername()}
				}
			}
		}
	}

	return {};
}

#*****************************************************************************************************
# Subroutine : getSettings
# In Param   : -
# Out Param  : HASH
# Objective  : Get user settings.
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub getSettings {
	my $c = {
		chk_update => getUserConfiguration('NOTIFYSOFTWAREUPDATE'),
		fail_val => getUserConfiguration('NFB'),
		notify_missing => (int(getUserConfiguration('NMB')) ? 1 : 0),
		missing_val => getUserConfiguration('NMB'),
		exclude_hidden => getUserConfiguration(''),
		txt_mpc => Common::getBackupDeviceName(),
		slide_throttle => getUserConfiguration('BWTHROTTLE'),
		ignore_accesserr => getUserConfiguration('IFPE'),
		chk_asksave => getUserConfiguration('RESTORELOCATIONPROMPT'),
		show_hidden => getUserConfiguration('SHOWHIDDEN'),
		lst_fullexclude => getExcludeItems($AppConfig::fullExcludeListFile),
		lst_partexclude => getExcludeItems($AppConfig::partialExcludeListFile),
		lst_regexexclude => getExcludeItems($AppConfig::regexExcludeListFile),
	};
	if (getUserConfiguration('ENGINECOUNT') == 4) {
		$c->{'chk_multiupld'} = 1;
	}
	else {
		$c->{'chk_multiupld'} = 0;
	}
	return $c;
}

#*****************************************************************************************************
# Subroutine : syncUpdates
# In Param   : -
# Out Param  : BOOLEAN
# Objective  : Sync locally modified data like backupset, a/c config/settings, etc. to dashboard server.
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub syncUpdates {
	$selfPID = (-f $selfPIDFile and getFileContents($selfPIDFile)) || -1;
	end() if ($$ != $selfPID);

debug("Groups: $grpName");
	my $nsFile = Common::getNSFile();
	my ($nsfh, %data);
	my $m = 0;
	loadNS();
	if (open($nsfh, '+<', $nsFile)) {
		unless (flock($nsfh, LOCK_EX)) {
			traceLog("Cannot lock file $nsFile $!\n");
			close($nsfh);
			sleep(3);
			next;
		}
	}
	else {
		traceLog("Cannot open file $nsFile $!\n");
		sleep(3);
		next;
	}

	if (getNS('register_dashboard') or
			getNS('update_acc_status') or getNS('get_user_settings')) {
		Common::loadUserConfiguration();
	}

	foreach my $n (keys %{getNS()->{'nsq'}}) {
debug("notify $n " . __LINE__);
		%data = (
			channeltype => $n,
			notification_value => getNS($n),
			dhbCon => $_[0]
		);
		my $fd = startActivity2(\%data, 1);
		if ($fd) {
			unless(looks_like_number($fd)) {
				$_[0]->write($fd);
debug("sendNTFY: $fd");
			}
debug("NTFY: $n = $data{'notification_value'}");
			unless (($n =~ /_progress$/) and $data{'notification_value'} =~ /_Running_/) {
				deleteNS($n);
				$m = 1 unless($m);
			}
		}
	}
	saveNS($nsfh) if ($m);
	close($nsfh);
}

#*****************************************************************************************************
# Subroutine : findMyGroup
# In Param   : STRING
# Out Param  : BOOLEAN
# Objective  : Check if the user belongs to the given group
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub findMyGroup {
	return 1 if ((($_[0] eq 'all')) or ($_[0] eq ''));
	my %grps = map {$_ => 1} split(',', $grpName);
	foreach my $g (split(',', $_[0])) {
		if (exists $grps{$g}) {
			return 1;
		}
	}

debug('No group found');
	return 0;
}

#*****************************************************************************************************
# Subroutine : startActivity2
# In Param   : STRING
# Out Param  : BOOLEAN or HASH
# Objective  : Runs an activity like start backup, schedule a backup, etc..
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub startActivity2 {
	if (($_[0] eq '--heartbeat--') or ($_[0] =~ 'idle timeout')) {
		return 0;
	}
	my ($ic, $data);
	$ic = $_[1] || 0;
	unless ($ic) {
		$data = from_json(decode_base64($_[0]));
	}
	else {
		$data = $_[0];
	}

	unless (exists $data->{'channeltype'}) {
debug('channeltype not defined');
		return FALSE;
	}

	my %activity = (
		register_dashboard => \&register2,

		update_acc_status => \&register2,

		info => sub {
			my %d = (
				channeltype => $data->{'channeltype'},
				bid => $data->{'bid'},
				content => getSysInfo()
			);
#			updateFileSetSize('backup');
#			updateFileSetSize('localbackup');
debug(Dumper('info: ', \%d));
			return encode_base64(to_json(\%d), '');
		},

		get_user_settings => sub {
			register2();
			saveChangesToDHB('settings', [getSettings()]);
			return TRUE;
		},

		treeview => sub {
			my $dirname = $data->{'content'}{'name'};
			if (utf8::is_utf8($dirname)) {
				utf8::downgrade($dirname);
			}
			$dirname = '/' if ($dirname eq 'root');
			my %d = (
				channeltype => $data->{'channeltype'},
				bid => $data->{'bid'},
			);
			my @files;
#			unless (-e $dirname) {
#				$files{'status'} = AppConfig::FAILURE;
#				$files{'errmsg'} = 'directory does not exists';
#			}
#			else {
				unless (-d $dirname) {
					Common::traceLog("Directory does not exists: $dirname");
					return 0;
				}

				if (exists $data->{'opType'} and ($data->{'opType'} eq 'localdrive')) {
					foreach my $filename (keys %{Common::getMountPoints('Writeable')}) {
						push(@files, {
							type => 'folder',
							path => $filename
						});
					}
					$d{'content'} = \@files;
					$d{'parent'} = $dirname;
					return encode_base64(to_json(\%d), '');
				}

				$dirname .= '/' unless (substr($dirname, -1) eq '/');
				opendir(my $dh, $dirname) or
					Common::retreat(['can not open', ":$dirname: $!"]);

#				$files{'status'} = AppConfig::SUCCESS;
				# $files{'dir'} = $dirname;

				my $filename = '';
				my $totalFileNameLength = 79;
				my $maxFileNameLength = 11000;
				while ($filename = readdir $dh) {
					next if (($filename =~ /^\.\.?$/) || (-l "$dirname$filename") || (!getUserConfiguration('SHOWHIDDEN') and "$dirname$filename" =~ /\/\./));

					last if ($totalFileNameLength > $maxFileNameLength);

					if (-d "$dirname$filename") {
						$totalFileNameLength += ((length $filename) + 25);
						push(@files, {
								type => 'folder',
								path => $filename
							});
#						$files{'files'}{"$filename"}{'type'} = 'd';
					}
					elsif (-f "$dirname$filename") {
						$totalFileNameLength += ((length $filename) + 27);
						push(@files, {
								type => 'file',
								path => $filename
							});
#						$files{'files'}{"$filename"}{'type'} = 'f';
					}
					$filename = '';
				}
				$d{'content'} = \@files;
				$d{'parent'} = $dirname;
				closedir $dh;
#			}

			return encode_base64(to_json(\%d), '');
		},

		lockinfo => sub {
			return applyPropSettings({
				config => $data->{'content'}
			});
		},

		getdefaultbkpset => sub {
			my %d = (
				channeltype => 'defaultbackupset',
				content => getFileSetContent('backup', (exists $data->{'recal'} ? $data->{'recal'} : 0))
			);
			if (exists $data->{'bid'}) {
				$d{'bid'} = $data->{'bid'};
			}
			else {
				$d{'bid'} = 'dummy';
			}
			return encode_base64(to_json(\%d), '');
		},

		defaultbackupset => sub {
			my $c;
			if (exists $data->{'grp'}) {
				return TRUE if ($data->{'content'}->[0]->{'bkpcontent'} eq '');

				my $d = from_json($data->{'content'}->[0]->{'bkpcontent'});
				if (exists $d->{'time'} and exists $data->{'ps'}) {
					if (exists $data->{'ps'}{'defaultbackupset'}) {
						if ($data->{'ps'}{'defaultbackupset'}{'time'} eq $d->{'time'}) {
debug('No change in defaultbackupset');
							return TRUE;
						}
					}
					$data->{'ps'}{'ismodified'} = 1;
					$data->{'ps'}{'defaultbackupset'}{'time'} = $d->{'time'};
				}
				foreach my $item (@{$d->{'value'}}){
					$item->{'path'} =~ s/\\$//g;
					$c->{'files'}{$item->{'path'}}{'type'} = ((substr($item->{'path'}, -1) eq '/') ? 'd' : 'f');
				}
				$c->{'grp'} = $data->{'grp'};
			}
			else {
				my %backupJobDetails = Common::getRunningJobs('backup');

				if (%backupJobDetails) {
					return encode_base64(to_json({
						channeltype => 'notify',
						bid => 'dummy',
						content => {
							type => lc(FAILURE),
							msg => 'backup is in progress please try again later'
						}
					}), '');
				}
				foreach my $item (@{$data->{'content'}}) {
					$c->{'files'}{$item->{'path'}}{'type'} = ((substr($item->{'path'}, -1) eq '/') ? 'd' : 'f');
				}
			}
debug(Dumper('backupset: ', $c));
			saveFileSetContent('backup', $c);
			return TRUE;
		},

		getlocalbkpset => sub {
			my %d = (
				channeltype => 'localbackupset',
				content => getFileSetContent('localbackup', (exists $data->{'recal'} ? $data->{'recal'} : 0))
			);
			if (exists $data->{'bid'}) {
				$d{'bid'} = $data->{'bid'};
			}
			else {
				$d{'bid'} = 'dummy';
			}
			return encode_base64(to_json(\%d), '');
		},

		localbackupset => sub {
			my $c;
			if (exists $data->{'grp'}) {
				return TRUE if ($data->{'content'}->[0]->{'bkpcontent'} eq '');

				my $d = from_json($data->{'content'}->[0]->{'bkpcontent'});
				if (exists $d->{'time'} and exists $data->{'ps'}) {
					if (exists $data->{'ps'}{'localbackupset'}) {
						if ($data->{'ps'}{'localbackupset'}{'time'} eq $d->{'time'}) {
debug('No change in localbackupset');
							return TRUE;
						}
					}
					$data->{'ps'}{'ismodified'} = 1;
					$data->{'ps'}{'localbackupset'}{'time'} = $d->{'time'};
				}
				foreach my $item (@{$d->{'value'}}){
					$item->{'path'} =~ s/\\$//g;
					$c->{'files'}{$item->{'path'}}{'type'} = ((substr($item->{'path'}, -1) eq '/') ? 'd' : 'f');
				}
				$c->{'grp'} = $data->{'grp'};
			}
			else {
				foreach my $item (@{$data->{'content'}}) {
					$c->{'files'}{$item->{'path'}}{'type'} = ((substr($item->{'path'}, -1) eq '/') ? 'd' : 'f');
				}
			}
debug(Dumper('localbackup: ', $c));
			saveFileSetContent('localbackup', $c);
		},

		getlog => sub {
			my %d = (
				channeltype => 'log',
				bid => $data->{'bid'},
				content     => getLogs()
			);
			return encode_base64(to_json(\%d), '');
		},

		get_logs => sub {
			saveChangesToDHB('logs', [{logdata => to_json(getLogs())}]);
		},

# TODO:
		logdetail => sub {
			return TRUE unless (exists $data->{'content'}{'operation'} and $data->{'content'}{'filename'});

			my $logDetails = getLog($data->{'content'}{'operation'}, $data->{'content'}{'filename'});
			my %d = (
				channeltype => 'logdetail',
				bid => $data->{'bid'},
			);
			if (exists $logDetails->{'details'}) {
				if (exists $logDetails->{'summary'}) {
					$d{'content'} = "$logDetails->{'summary'}";
				}
				$d{'content'} .= "\n\n</br>$logDetails->{'details'}";
			}
			$d{'content'} =~ s/\n/\r\n/g;
			return encode_base64(to_json(\%d), '');
		},

		logdelete => sub {
			return TRUE unless (exists $data->{'content'}{'operation'} and $data->{'content'}{'filename'});

			my @filename = split('_', $data->{'content'}{'filename'});

			unless (Common::deleteLog($data->{'content'}{'operation'}, $filename[0], ("$filename[1]_$filename[2]"))) {
			}
		},

		getsettings => sub {
			my %d = (
				channeltype => 'settings',
				bid => $data->{'bid'},
				content     => getSettings()
			);
			return encode_base64(to_json(\%d), '');
		},

		settings => sub {
			startActivity(DashboardUtility::parseSettings($data->{'content'}, getUsername(), getMachineUser()), undef, 1, 1);
		},

		getscheduler => sub {
			my %d = (
				channeltype => 'scheduler',
				bid => $data->{'bid'},
				content     => getScheduledJobs('backup')
			);
			return encode_base64(to_json(\%d), '');
		},

		scheduler => sub {
			return startActivity(
				DashboardUtility::parseSch(
					$data->{'content'}, getUsername(), getMachineUser()
				), undef, 1, 1
			);
		},

		getarchivecleanup => sub {
			if (Common::loadCrontab(getUsername())) {
				my $ct = Common::getCrontab();
				my %d = (
					channeltype => 'archivecleanup',
					bid => $data->{'bid'},
					content     => DashboardUtility::parseACForDHB(
						$ct->{$AppConfig::mcUser}{getUsername()}{'archive'}{'default_backupset'},
						getUsername()
					)
				);
				return encode_base64(to_json(\%d), '');
			}

			return TRUE;
		},

		archivecleanup => sub {
			startActivity(DashboardUtility::parseArchiveCleanup2($data->{'content'}, getUsername()), undef, 1, 1);
		},

		backup => sub {
			if ($data->{content}{'backupsetname'} eq ('Default BackupSet_' . getMachineUser())) {
				return startJob('backup_scripts', 'dashboard');
			}
			elsif ($data->{content}{'backupsetname'} eq ('LocalBackupSet_' . getMachineUser())) {
				return startJob('express_backup', 'dashboard');
			}
			return TRUE;
		},

		update_backup_progress => sub {
			return encode_base64(to_json(getProgressUpdates('backup', [split('_', $data->{'notification_value'})])), '');
		},

		update_localbackup_progress => sub {
			return encode_base64(to_json(getProgressUpdates('localbackup', [split('_', $data->{'notification_value'})])), '');
		},

		update_restore_progress => sub {
			return encode_base64(to_json(getProgressUpdates('restore', [split('_', $data->{'notification_value'})])), '');
		},

		alert_status_update => sub {
			register2({
				alert => (encode_base64(to_json([{
					type => (split('', $data->{'notification_value'}))[0],
					errcode => $data->{'notification_value'}
				}]), ''))
			});

			return TRUE;
		},

		restore => sub {
			setUserConfiguration('RESTOREFROM', (
				$AppConfig::deviceIDPrefix . $data->{'content'}{'device_id'} . $AppConfig::deviceIDSuffix .
				'#' . $data->{'content'}{'nick_name'}
			));
			setUserConfiguration('RESTORELOCATION', $data->{'content'}{'path'});
			saveUserConfiguration(0, 1);

			my $c = {};
			foreach my $item (split("\r\n", $data->{'content'}->{'content'})) {
				if (substr($item, -1) eq '/') {
					$c->{'files'}{$item}{'type'} = 'd';
				}
				else {
					my $i = rindex($item, ':');
					$c->{'files'}{substr($item, 0, $i)}{'type'} = 'f';
					$c->{'files'}{substr($item, 0, $i)}{'size'} = substr($item, $i+1);
				}
			}

			saveFileSetContent('restore', $c);
			return startJob('restore_script', 'dashboard');
			return TRUE;
		},

		restorestop => sub {
			if (exists $data->{'opType'} and ($data->{'opType'} eq 'localbackup')) {
				stopJob('localbackup');
			}
			elsif ((int($data->{'content'}{'prgtype'}) == 1) or (int($data->{'content'}{'prgtype'}) == 2)) {
				stopJob('backup');
			}
			elsif (int($data->{'content'}{'prgtype'}) == 3) {
				stopJob('restore');
			}
		},

		getpath => sub {
			my %d = (
				channeltype => 'getpath',
				bid => $data->{'bid'},
				content     => {
					path => getUserConfiguration('RESTORELOCATION')
				}
			);
			return encode_base64(to_json(\%d), '');
		},

		localdrive => sub {
			my %d = (
				channeltype => 'localdrive',
				bid => $data->{'bid'},
				content     => {
					drive => getUserConfiguration('LOCALMOUNTPOINT')
				}
			);
			return encode_base64(to_json(\%d), '');
		},

		setdrive => sub {
			setUserConfiguration('LOCALMOUNTPOINT', $data->{'content'}{'drive'});
			saveUserConfiguration(0, 1);
			return TRUE;
		},

		errorreport => sub {
			my $cmd = ("$AppConfig::perlBin " . Common::getScript('send_error_report', 1));
			$cmd   .= (' \'' . getUsername() . '\' \'' . $data->{'content'}{'email'} . '\' \'' . $data->{'content'}{'cno'} . '\'');
			$cmd   .= (' \'' . $data->{'content'}{'tno'} . '\' \'' . $data->{'content'}{'msg'} . '\'');

			$cmd = Common::updateLocaleCmd($cmd);
			unless (system($cmd) == 0) {
			}
		},

		startstop => sub {
			if (ref($data->{'content'}) eq 'ARRAY' ) {
				if (exists $data->{'content'}[0]{'install'}) {
					$data->{'content'}[0]{'install'} = from_json($data->{'content'}[0]{'install'});
					foreach my $machine (split(',', $data->{'content'}[0]{'install'}{'machines'})) {
						if ($machine eq (Common::getMachineUID(0) . '_' . hostname)) {
							my $cmd = sprintf("%s %s silent &", $AppConfig::perlBin, Common::getScript('check_for_update', 1));
							$cmd = Common::updateLocaleCmd($cmd);

							my %status;
							unless (system($cmd) == 0) {
								$status{'status'} = AppConfig::FAILURE;
							}
							else {
								$status{'status'} = AppConfig::SUCCESS;
							}
							last;
						}
					}
				}

				return TRUE;
			}
			if (exists $data->{'content'}{'blc'} and int($data->{'content'}{'blc'}) and Common::isLoggedin()) {
				setUserConfiguration('BDA', 1);
				saveUserConfiguration(0, 1);
				my $cmd = sprintf("%s %s 1 1 1>/dev/null 2>/dev/null &", $AppConfig::perlBin, Common::getScript('logout', 1));
				$cmd = Common::updateLocaleCmd($cmd);
				`$cmd`;
			}

			if (exists $data->{'content'}{'dk'} and int($data->{'content'}{'dk'})) {
				setUserConfiguration('DDA', 1);
				saveUserConfiguration(0, 1);
			}

			if (exists $data->{'content'}{'cmd'} and $data->{'content'}{'cmd'} eq 'install') {
				my $cmd = sprintf("%s %s silent &", $AppConfig::perlBin, Common::getScript('check_for_update', 1));
				$cmd = Common::updateLocaleCmd($cmd);

				my %status;
				unless (system($cmd) == 0) {
				$status{'status'} = AppConfig::FAILURE;
				}
				else {
					$status{'status'} = AppConfig::SUCCESS;
				}
			}

			return TRUE;
		},

		policy => sub {
			return applyPropSettings($data->{'content'});
		},

		update_groups => sub {
			my $users = $data->{'content'}{'users'};
			my $u = getUsername();
			foreach my $u (split(',', $data->{'content'}{'users'})) {
				if ($u eq getUsername()) {
					$grpName = $data->{'content'}{'newGroups'};
					last;
				}
			}
			return TRUE;
		},

		removeDevice => sub {
			my $did = Common::getBackupDeviceID();
			if (exists $data->{'content'}{'mid'} and exists $data->{'content'}{'did'} and
					($data->{'content'}{'mid'} eq Common::getMachineUID(0)) and
					($data->{'content'}{'did'} eq $did)) {
					setUserConfiguration('BACKUPLOCATION', '');
					saveUserConfiguration(0, 1);

					Common::traceLog('backup_location_is_adopted_by_another_machine');
					Common::loadCrontab();
					Common::setCrontab('otherInfo', 'settings', {'status' => 'INACTIVE'}, ' ');
					Common::saveCrontab(0);
					my $cmd = sprintf("%s %s 1 0", $AppConfig::perlBin, Common::getScript('logout', 1));
					$cmd = Common::updateLocaleCmd($cmd);
					`$cmd`;

					end();
			}
		},

		timeout => sub {
			$alarmintvl = (int($data->{'content'}) - 2);
		},

		get_scheduler => sub {
			if (Common::loadCrontab(getUsername())) {
				my $ct = Common::getCrontab();
				if (exists $ct->{$AppConfig::mcUser} and exists $ct->{$AppConfig::mcUser}{getUsername()}) {
					saveChangesToDHB('scheduler', DashboardUtility::parseSchForDHB($ct->{$AppConfig::mcUser}{getUsername()}, 'backup'));
				}
			}
			return TRUE;
		},

		get_settings => sub {
			saveChangesToDHB('settings', [getSettings()]);
			return TRUE;
		},

		deletecomputer => sub {
			my $d = $data->{'content'}[0];
			if (($d->{'mid'} eq Common::getMachineUID(0)) and
				($d->{'pname'} eq getMachineUser()) and
				($d->{'hname'} eq hostname) and
				($d->{'cname'} eq getUsername())) {
				deleteComputer();
				end();
			}
		},

	);

	$activity{'get_backupset_content'} = sub {
		if (exists $data->{'dhbCon'}) {
			$data->{'dhbCon'}->write($activity{'getdefaultbkpset'}('backup'));
		}
		else {
			return $activity{'getdefaultbkpset'}('backup');
		}

		my $c = [{
			bkpsetname => ('Default BackupSet_' . getMachineUser()),
			bkpcontent => to_json(getFileSetContent('backup')),
		}];
		saveChangesToDHB('backupset', $c);
		return TRUE;
	};

	$activity{'get_localbackupset_content'} = sub {
		if (exists $data->{'dhbCon'}) {
			$data->{'dhbCon'}->write($activity{'getlocalbkpset'}('localbackup'));
		}
		else {
			return $activity{'getlocalbkpset'}('localbackup');
		}

		my $c = [{
			bkpsetname => ('LocalBackupSet_' . getMachineUser()),
			bkpcontent => to_json(getFileSetContent('localbackup')),
		}];
		saveChangesToDHB('backupset', $c);
		return TRUE;
	};

	unless(exists $activity{$data->{'channeltype'}}) {
debug(Dumper('Activity: ' . $data->{'channeltype'} . ' Not defined'));
		return TRUE if (exists $data->{'notification_value'});
		return FALSE;
	}

	return FALSE if (exists $data->{'grp'} and not findMyGroup($data->{'grp'}));

	return FALSE if (exists $data->{'type'} and ($data->{'type'} ne 'linux'));

	return $activity{$data->{'channeltype'}}();
}

#*****************************************************************************************************
# Subroutine			: startActivity
# Objective				: Start an user activity
# Added By				: Yogesh Kumar
# Modified By			: Sabin Cheruvattil
#****************************************************************************************************/
sub startActivity {
	my $data = $_[0] || return 0;
	my $content;
	my $ic = 0;
	$ic = $_[3] if (defined $_[3]);

	$AppConfig::errorMsg = undef;

debug("ic $ic " . __LINE__);
	if (defined($_[2]) and $_[2]) {
		$content = $data->{'content'};
	}
	else {
		return 1 if ((not exists $data->{'content'}) || ($data->{'content'} eq ''));
		eval {
			$content = from_json(zlibRead($data->{'content'}));
			1;
		} or do {
			if ($@) {
				Common::traceLog("Exception: $@");
			}
			else {
				Common::traceLog("Uncaught exception");
			}
			return 0;
		};
	}

	my %activity = (

		'update_remote_manage_ip' => sub {
			my @responseData = Common::authenticateUser(getUsername(), &Common::getPdata(getUsername())) or return 0;
			return 0 if ($responseData[0]->{'STATUS'} eq 'FAILURE');

			return 0 if ((exists $responseData[0]->{'plan_type'}) and ($responseData[0]->{'plan_type'} eq 'Mobile-Only') and
				(exists $responseData[0]->{'accstat'}) and ($responseData[0]->{'accstat'} eq 'M'));
			my $rmip = getRemoteManageIP();
			my $prmip= getParentRemoteManageIP();

			setUserConfiguration(@responseData);
			saveUserConfiguration() or return 0;

			if (($rmip ne getRemoteManageIP()) or ($prmip ne getParentRemoteManageIP())) {
				return 1;
			}

			return 2;
		},

# TODO:
		'get_mount_points' => sub {
		},

		'save_user_settings' => sub {
			my @userConfig = ($content->{'user_settings'});
			my $errMsg = '';
			my %status;
			$status{'status'} = AppConfig::FAILURE;

			if (exists $userConfig[0]->{'BACKUPLOCATION'} and (getUserConfiguration('DEDUP') eq 'on') and
			($userConfig[0]->{'BACKUPLOCATION'} ne getUserConfiguration('BACKUPLOCATION'))) {
				my @bl = split('#', $userConfig[0]->{'BACKUPLOCATION'});
				my @rl = split('#', getUserConfiguration('RESTOREFROM'));
				$bl[0] = substr($bl[0], 4);
				$bl[0] = substr($bl[0], 0, -4);
				$rl[0] = substr($rl[0], 4);
				$rl[0] = substr($rl[0], 0, -4);

				my %deviceDetails = ('device_id' => $bl[0]);
				unless (Common::renameDevice(\%deviceDetails, $bl[1], $AppConfig::dashbtask)) {
					$errMsg = 'failed_to_rename_backup_location';
				}
				elsif ($bl[0] eq $rl[0]) {
					$userConfig[0]->{'RESTOREFROM'} = ($AppConfig::deviceIDPrefix .
						$deviceDetails{'device_id'} .$AppConfig::deviceIDSuffix ."#" . $bl[1]);
					#loadNotifications() and setNotification('register_dashboard') and saveNotifications();
				}
			}
			elsif (exists $userConfig[0]->{'BDA'} and int($userConfig[0]->{'BDA'}) and Common::isLoggedin()) {
				my $cmd = sprintf("%s %s 1 1 1>/dev/null 2>/dev/null &", $AppConfig::perlBin, Common::getScript('logout', 1));
				$cmd = Common::updateLocaleCmd($cmd);
				`$cmd`;
			}

			saveExcludeFiles($content);

# TODO:
#			if (!$ic && $userConfig[0]->{'SHOWHIDDEN'} ne getUserConfiguration('SHOWHIDDEN'))
			if (exists $userConfig[0]->{'SHOWHIDDEN'} and ($userConfig[0]->{'SHOWHIDDEN'} ne getUserConfiguration('SHOWHIDDEN'))) {
				Common::removeBKPSetSizeCache('backup');
				Common::removeBKPSetSizeCache('localbackup');
				system(
					Common::updateLocaleCmd(
						$AppConfig::perlBin . " " . Common::getScript('utility', 1) ." CALCULATEBACKUPSETSIZE backup 2>/dev/null &"
					)
				);
				system(
					Common::updateLocaleCmd(
						$AppConfig::perlBin . " " . Common::getScript('utility', 1) ." CALCULATEBACKUPSETSIZE localbackup 2>/dev/null &"
					)
				);
			}

			if (($errMsg eq '') and setUserConfiguration(@userConfig) and
				saveUserConfiguration(($ic > -1) ? $ic : 0)) {
				$status{'status'} = AppConfig::SUCCESS;
			}
			elsif ($AppConfig::errorMsg ne '') {
				if ($AppConfig::errorMsg eq 'settings_were_not_changed') {
					$status{'warnings'} = $AppConfig::errorMsg;
				}
				else {
					$status{'errmsg'} = $AppConfig::errorMsg;
				}
				$AppConfig::errorMsg = undef;
			}
			else {
				$status{'errmsg'} = $errMsg;
			}

			return 1;
		},

		'save_settings' => sub {
			saveExcludeFiles($content);

			Common::removeBKPSetSizeCache('backup');
			Common::removeBKPSetSizeCache('localbackup');
			system(
				Common::updateLocaleCmd(
					$AppConfig::perlBin . " " . Common::getScript('utility', 1) ." CALCULATEBACKUPSETSIZE backup 2>/dev/null &"
				)
			);
			system(
				Common::updateLocaleCmd(
					$AppConfig::perlBin . " " . Common::getScript('utility', 1) ." CALCULATEBACKUPSETSIZE localbackup 2>/dev/null &"
				)
			);

			if ($ic) {
				return 1 if ($ic < 0);
				loadNotifications() and setNotification('get_settings') and saveNotifications();
				return 1;
			}

			return 1;
		},

		'remote_install' => sub {
			my $cmd = sprintf("%s %s silent &", $AppConfig::perlBin, Common::getScript('check_for_update', 1));
			$cmd = Common::updateLocaleCmd($cmd);

			my %status;
			unless (system($cmd) == 0) {
				$status{'status'} = AppConfig::FAILURE;
			}
			else {
				$status{'status'} = AppConfig::SUCCESS;
			}

			return 1;
		},

		'save_scheduler' => sub {
			my $status = AppConfig::FAILURE;
			my $jt;
			my $fileset;
			my $errmsg = '';
			my $warnings = '';
			my %e;

			if (Common::checkCRONServiceStatus() != Common::CRON_RUNNING) {
				$warnings = 'IDrive cron service is stopped';
			}

debug(Dumper($content));
			if (exists $content->{'crontab'}{getUsername()} and Common::loadCrontab()) {
				foreach my $jobType (keys %{$content->{'crontab'}{getUsername()}}) {
					last if ($errmsg ne '');

					if ($jobType eq 'archive' and getUserConfiguration('DEDUP') eq 'off' and getUserConfiguration('BACKUPTYPE') =~ /relative/) {
						$warnings = 'no archive for relative backup type';
						next;
					}

					foreach my $jobName (keys %{$content->{'crontab'}{getUsername()}{$jobType}}) {
						# if backup set is empty don't update the schedule
						$jt = $jobType;
						$jt = 'localbackup' if ($jobName eq 'local_backupset');
						$jt = 'backup' if ($jt eq 'archive');
						if (exists $AppConfig::availableJobsSchema{$jt}) {
							$fileset = Common::getJobsPath($jt, 'file');
							unless (-f $fileset and !-z $fileset) {
								$warnings = "$jobName: backup set is empty\n";
								if (exists $content->{'crontab'}{getUsername()}{$jobType}{$jobName}{'settings'} and
								exists $content->{'crontab'}{getUsername()}{$jobType}{$jobName}{'settings'}{'frequency'} and
								$content->{'crontab'}{getUsername()}{$jobType}{$jobName}{'settings'}{'frequency'} eq 'immediate') {
									next;
								}
							}
						}

						unless (Common::setCrontab($jobType, $jobName, $content->{'crontab'}{getUsername()}{$jobType}{$jobName})) {
							Common::createCrontab($jobType, $jobName);
							Common::setCrontab($jobType, $jobName, $content->{'crontab'}{getUsername()}{$jobType}{$jobName});
						}

						#Checking if another job is already in progress
						if (Common::getCrontab($jobType, $jobName, '{settings}{frequency}') eq 'immediate') {
							my $isJobRunning = Common::isJobRunning($jobName);
							if ($isJobRunning) {
								# need to return error message to dashboard.
debug('backup_job_is_already_in_progress_try_again');
								$status = AppConfig::FAILURE;
								$errmsg = 'Job_is_already_in_progress_Please_try_again';
								last;
							}
						}
						%e = Common::setCronCMD($jobType, $jobName);
						if ($e{'status'} eq AppConfig::FAILURE) {
							$status = AppConfig::FAILURE;
							$errmsg = $e{'errmsg'} || '';
							last;
						}
					}
				}

				if ($errmsg eq '') {
					$status = AppConfig::SUCCESS;
					Common::saveCrontab((($ic > -1) ? $ic : 0));
				}
			}

			if ($errmsg) {
				return encode_base64(to_json({
					channeltype => 'notify',
					bid => 'dummy',
					content => {
						type => lc(FAILURE),
						msg => $errmsg
					}
				}), '');
			}
			elsif ($warnings) {
				return encode_base64(to_json({
					channeltype => 'notify',
					bid => 'dummy',
					content => {
						type => 'warnings',
						msg => $warnings
					}
				}), '');
			}

			return TRUE;
		},

# TODO:
		'update_device_info' => sub {
		}
	);

	if ($content->{'channel'} and $activity{$content->{'channel'}}) {
debug("CHANNEL: $content->{'channel'}");

		my $uConfStatus = Common::loadUserConfiguration();
		if (defined($_[1]) and $_[1]) {
			if (($uConfStatus != 1) and ($content->{'channel'} ne 'connect')) {
				my $errMsg = '';
				$errMsg = $AppConfig::errorDetails{$uConfStatus} if (exists $AppConfig::errorDetails{$uConfStatus});
debug("error msg $errMsg ");
				return $activity{'send_error_msg'}($errMsg);
			}
		}
		my $actStatus = 0;
		eval {
			$actStatus = $activity{$content->{'channel'}}();
			1;
		} or do {
			$actStatus = 0;
			if ($@) {
				Common::traceLog("Exception: $@");
			}
			else {
				Common::traceLog("Uncaught exception");
			}
		};
		return $actStatus;
	}
	elsif (defined($_[2]) and $_[2]) {
		return 1;
	}

	Common::traceLog('CHANNEL: ' . ($content->{'channel'} || '') . ' not defined');
	return 0;
}

#*****************************************************************************************************
# Subroutine : watchDashboardLoginActivity2
# In Param   : -
# Out Param  : -
# Objective  : Watch for dashboard activities
# Added By   : Yogesh Kumar
#****************************************************************************************************/
sub watchDashboardLoginActivity2 {
	my $ep;
	if (getUserConfiguration('ADDITIONALACCOUNT') eq 'true') {
		$ep = (encode_base64(getParentUsername(), '') . '/' . encode_base64(getUsername(), ''));
	}
	else {
		$ep = encode_base64(getUsername(), '');
	}
	my $resData = request2({
			url => getRemoteManageIP(),
			port=> $wsport,
			path=> ('ws/evsnotify/' . $ep . '/' . encode_base64((Common::getMachineUID(0) . '_' . getMachineUser()), '') . '/'),
			headers=> [
				'client', 'a9f6ca87a786',
				'st', Idrivelib::get_dashboard_params({101=>$at},1,0)->{'data'}{'st'},
				'cname', getUsername(),
				'aname', getParentUsername(),
				'pname', getMachineUser(),
				'mid', Common::getMachineUID(0),
				'cnameb64', encode_base64(getUsername(), ''),
				'anameb64', encode_base64(getParentUsername(), '')
			],
			blocking=> 0
		});

	return TRUE;
}

#*****************************************************************************************************
# Subroutine			: stopDashboardRoutines
# Objective				: Stop all sub process
# Added By				: Yogesh Kumar
#****************************************************************************************************/
sub stopDashboardRoutines {
	return TRUE;
}

#*****************************************************************************************************
# Subroutine			: end
# Objective				: Kill all process before this script exit
# Added By				: Yogesh Kumar
#****************************************************************************************************/
sub end {
	exit(0);
}

1;
